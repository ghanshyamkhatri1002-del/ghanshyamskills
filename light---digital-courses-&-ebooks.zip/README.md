# LIGHT — Minimalist Digital Course & Ebook Selling Platform

LIGHT is a high-converting, mobile-first creator digital storefront engineered for selling courses and ebooks with instant manual UPI QR payments, screenshot proof verification, automated WhatsApp & email notifications, and encrypted customer access links.

---

## ⚡ Core Purpose & Workflow

```
Creator Profile (/light)
  ↓
Product Catalog (Courses & Ebooks)
  ↓
Product Details (/product/[slug])
  ↓
Buy Now (Name, Email, WhatsApp)
  ↓
Instant UPI QR Payment (/payment/[orderId])
  ↓
Customer Uploads Payment Screenshot
  ↓
Admin Review & Verification (/admin/orders)
  ↓
Admin Approves Payment
  ↓
Automated WhatsApp & Email Notifications Dispatched
  ↓
Customer Accesses Paid Content (/access/[secureToken])
  - Streams video lessons or downloads encrypted PDF directly
```

---

## 🚀 Features

- **Mobile-First Profile Storefront (`/light` / `/`)**:
  - Maximum 560px content width, centered on larger screens.
  - Creator avatar, bio, and segmented tabs: *All Products*, *Courses*, *Ebooks*.
  - Clean, unboxed metadata and rounded product cards with subtle elevation.
- **Frictionless Checkout**:
  - Buy Now modal captures customer name, email address, and WhatsApp number.
  - Automatically creates a secure order record in `PENDING_PAYMENT` state.
- **UPI QR Payment Screen (`/payment/:orderId`)**:
  - Large QR code for PhonePe, Google Pay, Paytm, and BHIM UPI apps.
  - Displays payable amount and one-click copyable UPI ID.
  - Drag-and-drop or file upload for payment screenshot (JPG, PNG, WEBP, up to 10MB) with instant client-side preview.
  - Transitions to live verification progress tracker once proof is submitted.
- **Admin Management Panel (`/admin`)**:
  - **Login (`/admin/login`)**: Secure authentication (default: `admin@light.store` / `admin123456`).
  - **Dashboard (`/admin`)**: Metric cards for *Total Products*, *Total Orders*, *Pending Payments*, *Approved Orders*, and recent orders.
  - **Catalog (`/admin/products`)**: Create, edit, and delete courses and ebooks.
  - **Orders (`/admin/orders`)**: Filter by status (*Verification Needed*, *Approved*, *Rejected*). Modal displays payment screenshots with click-to-zoom.
  - **Approve Workflow**: Unlocks lifetime access, generates cryptographically random token (`crypto.randomBytes(32)`), and triggers notifications.
  - **Reject Workflow**: Prompts for rejection reason and updates customer.
  - **Direct WhatsApp Chat**: One-click button to open WhatsApp Web with the pre-filled verification message and access link for the customer.
  - **Settings (`/admin/settings`)**: Update creator name, bio, profile image, UPI QR code, UPI ID, and support numbers.
- **Secure File Delivery (`/access/:token`)**:
  - Validates token against database; access denied if unapproved or expired.
  - For Courses: Interactive on-demand video player / hosted curriculum links.
  - For Ebooks: Secure streaming download endpoint (`/api/access/download/:token`) that protects raw file paths.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons
- **Backend**: Node.js, Express, Multer for multipart uploads
- **Storage**: Safe persistent JSON storage layer with atomic file-swap writes, plus separated public & private upload directories
- **Security**: PBKDF2 password hashing with salt, cryptographically secure 64-character hex access tokens, protected streaming endpoints

---

## ⚙️ Environment Variables

Create or adjust `.env`:

```env
# Server Port & App URL
PORT=3000
APP_URL="http://localhost:3000"

# Admin Authentication
ADMIN_EMAIL="admin@light.store"
ADMIN_PASSWORD="admin123456"

# WhatsApp Business API (Optional — Mock mode & Direct WhatsApp Web active by default)
WHATSAPP_API_URL="https://graph.facebook.com/v18.0"
WHATSAPP_ACCESS_TOKEN=""
WHATSAPP_PHONE_NUMBER_ID=""

# SMTP Email Configuration (Optional — Mock mode active by default)
SMTP_HOST=""
SMTP_PORT="587"
SMTP_USER=""
SMTP_PASSWORD=""
EMAIL_FROM="orders@light.store"
```

---

## 📦 Installation & Setup

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start Development Server**:
   ```bash
   npm run dev
   ```

3. **Build for Production**:
   ```bash
   npm run build
   ```

4. **Run Production Server**:
   ```bash
   npm start
   ```

---

## 🔑 Default Admin Credentials

- **URL**: `http://localhost:3000/admin/login`
- **Email**: `admin@light.store`
- **Password**: `admin123456`
*(Quick "Fill Demo Credentials" button available on login page)*
