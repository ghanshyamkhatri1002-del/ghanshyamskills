import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import dotenv from 'dotenv';
import {
  db,
  PUBLIC_UPLOADS_DIR,
  PRIVATE_UPLOADS_DIR,
  PUBLIC_PROFILE_DIR,
  PUBLIC_THUMBNAILS_DIR,
  PRIVATE_EBOOKS_DIR,
  PRIVATE_COURSE_CONTENT_DIR,
  PRIVATE_PAYMENT_SCREENSHOTS_DIR,
  PRIVATE_QR_DIR,
} from './src/server/db.ts';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Body parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve public uploads statically
app.use('/uploads/public', express.static(PUBLIC_UPLOADS_DIR));

// Helper for generating clean unique filenames
function createSafeFilename(originalName: string, prefix = 'file'): string {
  const ext = path.extname(originalName).toLowerCase();
  const baseName = path
    .basename(originalName, ext)
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_')
    .substring(0, 30);
  return `${prefix}_${Date.now()}_${baseName}${ext}`;
}

// 1. Thumbnail Storage (Public)
const thumbnailStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PUBLIC_THUMBNAILS_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'thumb')),
});

const uploadThumbnail = multer({
  storage: thumbnailStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG, JPG, JPEG, or WEBP image files are allowed.'));
    }
  },
});

// 2. Profile Storage (Public)
const profileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PUBLIC_PROFILE_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'profile')),
});

const uploadProfile = multer({
  storage: profileStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG, JPG, JPEG, or WEBP image files are allowed.'));
    }
  },
});

// 3. QR Storage (Private storage with controlled preview)
const qrStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_QR_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'qr')),
});

const uploadQr = multer({
  storage: qrStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|svg\+xml|svg/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG, JPG, JPEG, WEBP, or SVG image files are allowed.'));
    }
  },
});

// 4. Ebook Storage (Private)
const ebookStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_EBOOKS_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'ebook')),
});

const uploadEbook = multer({
  storage: ebookStorage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (_req, file, cb) => {
    const allowed = /pdf|epub/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF or EPUB files are allowed.'));
    }
  },
});

// 5. Course Content Storage (Private)
const courseContentStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_COURSE_CONTENT_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'course')),
});

const uploadCourseContent = multer({
  storage: courseContentStorage,
  limits: { fileSize: 150 * 1024 * 1024 }, // 150MB
});

// 6. Payment Screenshot Storage (Private)
const screenshotStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_PAYMENT_SCREENSHOTS_DIR),
  filename: (_req, file, cb) => cb(null, createSafeFilename(file.originalname, 'proof')),
});

const uploadScreenshot = multer({
  storage: screenshotStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG, JPG, JPEG, or WEBP screenshot files are allowed.'));
    }
  },
});

// Legacy generic uploaders for fallback
const uploadPublic = uploadThumbnail;
const uploadPrivate = uploadEbook;

// Admin auth middleware
interface AuthenticatedRequest extends Request {
  admin?: { id: string; email: string; name: string };
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Admin authentication required' });
  }
  const token = authHeader.split('Bearer ')[1].trim();
  const admin = db.verifyAdminSession(token);
  if (!admin) {
    return res.status(401).json({ error: 'Unauthorized: Session invalid or expired' });
  }
  req.admin = admin;
  next();
}

// Base app URL helper
function getAppUrl(req: Request): string {
  if (process.env.APP_URL && !process.env.APP_URL.includes('MY_APP_URL')) {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.get('host') || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

// ==========================================
// PUBLIC API ROUTES
// ==========================================

// Get public storefront settings
app.get('/api/settings', (_req, res) => {
  const settings = db.getSettings();
  res.json({
    creatorName: settings.creatorName,
    subtitle: settings.subtitle,
    creatorBio: settings.creatorBio,
    profileImage: settings.profileImage,
    heroBackgroundImage: settings.heroBackgroundImage,
    heroHeading: settings.heroHeading,
    heroSubtitle: settings.heroSubtitle,
    heroDescription: settings.heroDescription,
    heroCtaText: settings.heroCtaText,
    upiId: settings.upiId,
    paymentInstructions: settings.paymentInstructions,
    paymentQrCode: settings.paymentQrCode,
    whatsappNumber: settings.whatsappNumber,
    whatsappButtonText: settings.whatsappButtonText,
    whatsappButtonIcon: settings.whatsappButtonIcon,
    whatsappButtonVisible: settings.whatsappButtonVisible,
    supportWhatsappNumber: settings.supportWhatsappNumber,
    bgTheme: settings.bgTheme,
    accentColor: settings.accentColor,
    primaryColor: settings.primaryColor,
    secondaryColor: settings.secondaryColor,
    buttonColor: settings.buttonColor,
    footerText: settings.footerText,
  });
});

// Get active products for profile storefront
app.get('/api/products', (_req, res) => {
  const products = db.getProducts(true);
  res.json(products);
});

// Get product details by slug
app.get('/api/products/:slug', (req, res) => {
  const product = db.getProductBySlug(req.params.slug);
  if (!product || product.status !== 'active') {
    return res.status(404).json({ error: 'Product not found' });
  }
  res.json(product);
});

// Create an order (Buy Now checkout)
app.post('/api/orders', (req, res) => {
  const { productId, name, email, whatsapp } = req.body;

  if (!productId || !name || !email || !whatsapp) {
    return res.status(400).json({ error: 'All fields (Name, Email, WhatsApp) are required' });
  }

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address' });
  }

  // Basic phone validation (at least 8 digits)
  const digitsOnly = whatsapp.replace(/\D/g, '');
  if (digitsOnly.length < 8) {
    return res.status(400).json({ error: 'Please enter a valid WhatsApp phone number' });
  }

  try {
    const order = db.createOrder({
      productId,
      customerName: name,
      customerEmail: email,
      customerWhatsapp: whatsapp,
    });
    res.status(201).json(order);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create order' });
  }
});

// Get order details for payment page
app.get('/api/orders/:id', (req, res) => {
  const order = db.getOrderById(req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  const settings = db.getSettings();
  res.json({
    order,
    paymentInfo: {
      upiId: settings.upiId,
      qrCodeUrl: settings.paymentQrCode,
      supportWhatsapp: settings.supportWhatsappNumber,
      creatorName: settings.creatorName,
    },
  });
});

// Upload payment screenshot handler with safe multer error handling
const safeUploadScreenshot = (req: Request, res: Response, next: NextFunction) => {
  uploadScreenshot.single('screenshot')(req, res, (err: any) => {
    if (err) {
      console.error('Screenshot upload multer error:', err);
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({
            success: false,
            message: 'Screenshot file size exceeds 10MB limit. Please upload a smaller image.',
          });
        }
        return res.status(400).json({ success: false, message: err.message });
      }
      return res.status(400).json({
        success: false,
        message: err.message || 'Invalid image format. Only JPG, PNG, and WEBP are accepted.',
      });
    }
    next();
  });
};

const handlePaymentScreenshot = (req: Request, res: Response) => {
  const orderId = req.params.id || req.body?.orderId;
  if (!orderId) {
    return res.status(400).json({ success: false, message: 'Order ID is required' });
  }

  const order = db.getOrderById(orderId);
  if (!order) {
    return res.status(404).json({ success: false, message: 'Order not found' });
  }

  if (!req.file) {
    return res.status(400).json({
      success: false,
      message: 'Please select a payment screenshot image (JPG, PNG, WEBP)',
    });
  }

  // Store relative path to private screenshot
  const screenshotRelativePath = `/api/admin/orders/${orderId}/screenshot-file/${req.file.filename}`;

  try {
    const updatedOrder = db.submitPaymentScreenshot(orderId, screenshotRelativePath);
    res.json({
      success: true,
      message: 'Payment screenshot submitted successfully. Your payment is being verified.',
      order: updatedOrder,
    });
  } catch (err: any) {
    console.error('Screenshot submission error:', err);
    res.status(500).json({
      success: false,
      message: 'Something went wrong while submitting your payment. Please try again.',
    });
  }
};

app.post('/api/orders/:id/screenshot', safeUploadScreenshot, handlePaymentScreenshot);
app.post('/api/orders/:id/submit-payment', safeUploadScreenshot, handlePaymentScreenshot);
app.post('/api/orders/submit-payment', safeUploadScreenshot, handlePaymentScreenshot);

// Customer Product Access verification
app.get('/api/access/:token', (req, res) => {
  const result = db.getProductAccessByToken(req.params.token);
  if (!result) {
    return res.status(403).json({
      error: 'Invalid, expired, or unverified access link. Please verify your payment status.',
    });
  }

  // Safe product representation (exclude internal raw paths)
  const safeProduct = {
    id: result.product.id,
    type: result.product.type,
    title: result.product.title,
    thumbnailUrl: result.product.thumbnailUrl,
    shortDescription: result.product.shortDescription,
    description: result.product.description,
    contentUrl: result.product.contentUrl,
    lessons: result.product.lessons,
    hasDownloadableFile: Boolean(result.product.fileUrl),
    fileName: result.product.fileName || 'download.pdf',
  };

  res.json({
    success: true,
    access: {
      id: result.access.id,
      status: result.access.status,
      createdAt: result.access.createdAt,
    },
    product: safeProduct,
    customer: {
      name: result.customer.name,
      email: result.customer.email,
    },
    order: {
      id: result.order.id,
      amount: result.order.amount,
      createdAt: result.order.createdAt,
    },
  });
});

// Secure protected file download endpoint
app.get('/api/access/download/:token', (req, res) => {
  const result = db.getProductAccessByToken(req.params.token);
  if (!result) {
    return res.status(403).json({ error: 'Access denied: invalid or unverified token' });
  }

  const fileUrl = result.product.fileUrl;
  if (!fileUrl) {
    return res.status(404).json({ error: 'No downloadable file attached to this product.' });
  }

  // Resolve absolute file path safely
  let filePath = fileUrl;
  if (!path.isAbsolute(filePath)) {
    filePath = path.resolve(process.cwd(), fileUrl.startsWith('/') ? '.' + fileUrl : fileUrl);
  }

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'The requested file is not available on the server.' });
  }

  const downloadName = result.product.fileName || path.basename(filePath);
  res.download(filePath, downloadName, (err) => {
    if (err && !res.headersSent) {
      console.error('File download stream error:', err);
      res.status(500).json({ error: 'Error streaming file' });
    }
  });
});

// ==========================================
// ADMIN API ROUTES (PROTECTED)
// ==========================================

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const admin = db.verifyAdmin(email, password);
  if (!admin) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const token = db.createAdminSession(admin.id);
  res.json({
    success: true,
    token,
    admin: { id: admin.id, email: admin.email, name: admin.name },
  });
});

// Admin verify session
app.get('/api/admin/me', requireAdmin, (req: AuthenticatedRequest, res) => {
  res.json({ admin: req.admin });
});

// Admin logout
app.post('/api/admin/logout', requireAdmin, (req: AuthenticatedRequest, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split('Bearer ')[1].trim();
    db.deleteAdminSession(token);
  }
  res.json({ success: true });
});

// Admin dashboard stats
app.get('/api/admin/dashboard', requireAdmin, (_req, res) => {
  const products = db.getProducts();
  const orders = db.getOrders();

  const totalProducts = products.length;
  const publishedCourses = products.filter((p) => p.status === 'active').length;
  const draftCourses = products.filter((p) => p.status === 'draft').length;
  const totalOrders = orders.length;
  const pendingPayments = orders.filter(
    (o) => o.status === 'PENDING_PAYMENT' || o.status === 'PAYMENT_SUBMITTED' || o.status === 'PENDING'
  ).length;
  const approvedOrders = orders.filter((o) => o.status === 'APPROVED' || o.status === 'PAID').length;
  const totalRevenue = orders
    .filter((o) => o.status === 'APPROVED' || o.status === 'PAID')
    .reduce((sum, o) => sum + o.amount, 0);

  const recentOrders = orders.slice(0, 5);

  res.json({
    stats: {
      totalProducts,
      publishedCourses,
      draftCourses,
      totalOrders,
      pendingPayments,
      approvedOrders,
      totalRevenue,
    },
    recentOrders,
  });
});

// Admin get all products
app.get('/api/admin/products', requireAdmin, (_req, res) => {
  const products = db.getProducts();
  res.json(products);
});

// Admin create product
app.post('/api/admin/products', requireAdmin, (req, res) => {
  const {
    type,
    title,
    thumbnailUrl,
    shortDescription,
    description,
    price,
    originalPrice,
    discountPercentage,
    showBadge,
    badgeText,
    badgeBgColor,
    badgeTextColor,
    badgePosition,
    duration,
    lessonCount,
    instructor,
    contentUrl,
    fileUrl,
    fileName,
    status,
    lessons,
  } = req.body;

  if (!type || !title || !price || !thumbnailUrl || !shortDescription) {
    return res.status(400).json({ error: 'Product type, title, thumbnail, short description, and price are required' });
  }

  // Generate URL slug from title
  let slug = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
  if (!slug) slug = 'product-' + Date.now();

  // Ensure slug uniqueness
  let finalSlug = slug;
  let counter = 1;
  while (db.getProductBySlug(finalSlug)) {
    finalSlug = `${slug}-${counter}`;
    counter++;
  }

  try {
    const product = db.createProduct({
      type,
      title,
      slug: finalSlug,
      thumbnailUrl,
      shortDescription,
      description: description || shortDescription,
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : undefined,
      discountPercentage: discountPercentage ? Number(discountPercentage) : undefined,
      showBadge: Boolean(showBadge),
      badgeText: badgeText || undefined,
      badgeBgColor: badgeBgColor || undefined,
      badgeTextColor: badgeTextColor || undefined,
      badgePosition: badgePosition || undefined,
      duration: duration || '3.5 Hours',
      lessonCount: lessonCount || '14 Lessons',
      instructor: instructor || 'Ghanshyam',
      contentUrl: contentUrl || '',
      fileUrl: fileUrl || '',
      fileName: fileName || '',
      status: status || 'active',
      lessons: Array.isArray(lessons) ? lessons : [],
    });
    res.status(201).json(product);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to create product' });
  }
});

// Admin update product
app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
  const product = db.getProductById(req.params.id);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const updated = db.updateProduct(req.params.id, req.body);
  res.json(updated);
});

// Admin delete product
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  const productId = req.params.id;
  const product = db.getProductById(productId);
  if (!product) {
    return res.status(404).json({ success: false, error: 'Course not found' });
  }

  const deleted = db.deleteProduct(productId);
  if (!deleted) {
    return res.status(500).json({ success: false, error: 'Failed to delete course from database' });
  }

  res.json({ success: true, message: 'Course deleted successfully.' });
});

// Admin archive product
app.post('/api/admin/products/:id/archive', requireAdmin, (req, res) => {
  const productId = req.params.id;
  const updated = db.updateProduct(productId, { status: 'archived' });
  if (!updated) {
    return res.status(404).json({ success: false, error: 'Course not found' });
  }
  res.json({ success: true, message: 'Course archived successfully.', product: updated });
});

// Admin get all orders
app.get('/api/admin/orders', requireAdmin, (_req, res) => {
  const orders = db.getOrders();
  res.json(orders);
});

// Admin approve order
app.post('/api/admin/orders/:id/approve', requireAdmin, async (req, res) => {
  const appUrl = getAppUrl(req);
  try {
    const result = await db.approveOrder(req.params.id, appUrl);
    res.json({
      success: true,
      message: 'Order approved successfully.',
      order: result.order,
      access: result.access,
      isCourse: result.isCourse,
      destinationUrl: result.destinationUrl,
      courseUrl: result.courseUrl,
      secureAccessUrl: result.destinationUrl,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to approve order' });
  }
});

// Admin reject order
app.post('/api/admin/orders/:id/reject', requireAdmin, async (req, res) => {
  const { reason } = req.body;
  try {
    const order = await db.rejectOrder(req.params.id, reason);
    res.json({
      success: true,
      message: 'Order rejected. Notification sent to customer.',
      order,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to reject order' });
  }
});

// Admin view protected payment screenshot file
app.get('/api/admin/orders/:id/screenshot-file/:filename', (req, res) => {
  const safeFilename = path.basename(req.params.filename);
  let filePath = path.join(PRIVATE_PAYMENT_SCREENSHOTS_DIR, safeFilename);
  if (!fs.existsSync(filePath)) {
    filePath = path.join(PRIVATE_UPLOADS_DIR, safeFilename);
  }
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Screenshot file not found');
  }
  res.sendFile(filePath);
});

// Serve private QR image for checkout/payment
app.get('/api/qr-image/:filename', (req, res) => {
  const safeFilename = path.basename(req.params.filename);
  let filePath = path.join(PRIVATE_QR_DIR, safeFilename);
  if (!fs.existsSync(filePath)) {
    filePath = path.join(PUBLIC_UPLOADS_DIR, safeFilename);
  }
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('QR image not found');
  }
  res.sendFile(filePath);
});

// Admin get settings
app.get('/api/admin/settings', requireAdmin, (_req, res) => {
  const settings = db.getSettings();
  res.json(settings);
});

// Admin update settings
app.put('/api/admin/settings', requireAdmin, (req, res) => {
  const updated = db.updateSettings(req.body);
  res.json(updated);
});

// Admin notification logs
app.get('/api/admin/notifications', requireAdmin, (_req, res) => {
  res.json({
    whatsapp: db.getWhatsAppLogs(),
    email: db.getEmailLogs(),
  });
});

// Dedicated upload endpoints
app.post(
  '/api/admin/upload/thumbnail',
  requireAdmin,
  uploadThumbnail.single('image'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No thumbnail file uploaded' });
    }
    const fileUrl = `/uploads/public/thumbnails/${req.file.filename}`;
    res.json({
      url: fileUrl,
      filename: req.file.originalname,
      size: req.file.size,
    });
  }
);

app.post(
  '/api/admin/upload/profile',
  requireAdmin,
  uploadProfile.single('image'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No profile avatar uploaded' });
    }
    const fileUrl = `/uploads/public/profile/${req.file.filename}`;
    res.json({
      url: fileUrl,
      filename: req.file.originalname,
      size: req.file.size,
    });
  }
);

app.post(
  '/api/admin/upload/hero-background',
  requireAdmin,
  uploadProfile.single('image'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No hero background image uploaded' });
    }
    const fileUrl = `/uploads/public/profile/${req.file.filename}`;
    res.json({
      url: fileUrl,
      filename: req.file.originalname,
      size: req.file.size,
    });
  }
);

app.post(
  '/api/admin/upload/qr',
  requireAdmin,
  uploadQr.single('image'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No QR code image uploaded' });
    }
    // Also copy to public QR if needed or serve via /api/qr-image
    const fileUrl = `/api/qr-image/${req.file.filename}`;
    res.json({
      url: fileUrl,
      filename: req.file.originalname,
      size: req.file.size,
    });
  }
);

app.post(
  '/api/admin/upload/ebook',
  requireAdmin,
  uploadEbook.single('file'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No ebook file uploaded' });
    }
    const fileUrl = `/data/uploads/private/ebooks/${req.file.filename}`;
    res.json({
      fileUrl,
      fileName: req.file.originalname,
      size: req.file.size,
    });
  }
);

app.post(
  '/api/admin/upload/course-content',
  requireAdmin,
  uploadCourseContent.single('file'),
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No course video/file uploaded' });
    }
    const fileUrl = `/data/uploads/private/course-content/${req.file.filename}`;
    res.json({
      fileUrl,
      fileName: req.file.originalname,
      size: req.file.size,
    });
  }
);

// Fallback legacy upload endpoints
app.post('/api/admin/upload/public', requireAdmin, uploadThumbnail.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  const fileUrl = `/uploads/public/thumbnails/${req.file.filename}`;
  res.json({ url: fileUrl, filename: req.file.originalname, size: req.file.size });
});

app.post('/api/admin/upload/private', requireAdmin, uploadEbook.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  const fileUrl = `/data/uploads/private/ebooks/${req.file.filename}`;
  res.json({
    fileUrl,
    fileName: req.file.originalname,
    size: req.file.size,
  });
});

app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Server error:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'An unexpected error occurred.',
  });
});

// ==========================================
// CLIENT SERVING & VITE INTEGRATION
// ==========================================

async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GHANSHYAM SKILLS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup failed:', err);
  process.exit(1);
});
