import React, { useState, useEffect } from 'react';
import { Product, SiteSettings } from '../types.ts';
import { ProductCard } from '../components/ProductCard.tsx';
import { CheckoutModal } from '../components/CheckoutModal.tsx';
import {
  MessageCircle,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  RefreshCw,
  PhoneCall,
  HelpCircle,
  GraduationCap,
} from 'lucide-react';

interface StorefrontPageProps {
  navigate: (path: string) => void;
}

export const StorefrontPage: React.FC<StorefrontPageProps> = ({ navigate }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        setIsLoading(true);
        const [prodRes, setRes] = await Promise.all([
          fetch('/api/products'),
          fetch('/api/settings'),
        ]);
        if (prodRes.ok) {
          const prods: Product[] = await prodRes.json();
          // Filter strictly to courses only
          setProducts(prods.filter((p) => p.type === 'course'));
        }
        if (setRes.ok) {
          const sets: SiteSettings = await setRes.json();
          setSettings(sets);
        }
      } catch (err) {
        console.error('Failed to load store data:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  const creatorName = settings?.creatorName || 'GHANSHYAM SKILLS';
  const subtitle = settings?.subtitle || 'Learn Skills. Build Your Future.';
  const bio =
    settings?.creatorBio ||
    'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.';
  const profileImg =
    settings?.profileImage ||
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&h=600&q=80';
  const rawWhatsApp = settings?.whatsappNumber || '+91 7976028995';
  const cleanWhatsAppNumber = rawWhatsApp.replace(/\D/g, '') || '917976028995';
  const waButtonText = settings?.whatsappButtonText || '💬 Chat on WhatsApp';
  const isWaVisible = settings?.whatsappButtonVisible !== false;
  const heroBg = settings?.heroBackgroundImage || '';

  // Icon mapping for custom whatsapp button icon
  const renderWaIcon = () => {
    switch (settings?.whatsappButtonIcon) {
      case 'phone':
        return <PhoneCall className="w-4 h-4 text-emerald-400" />;
      case 'help':
        return <HelpCircle className="w-4 h-4 text-emerald-400" />;
      case 'square':
        return <MessageSquare className="w-4 h-4 text-emerald-400" />;
      default:
        return <MessageCircle className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#07050E] text-slate-100 relative overflow-hidden pb-24">
      {/* Background Ambient Gradients (Black, Deep Purple, Magenta, Pink, Violet, Neon Glow) */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[520px] bg-gradient-to-b from-violet-600/25 via-fuchsia-600/20 to-transparent blur-[130px] pointer-events-none -z-0" />
      <div className="absolute top-36 -left-20 w-[450px] h-[450px] bg-purple-700/15 blur-[140px] pointer-events-none -z-0" />
      <div className="absolute top-52 -right-20 w-[450px] h-[450px] bg-pink-600/15 blur-[140px] pointer-events-none -z-0" />

      {/* Optional Custom Hero Background Banner */}
      {heroBg && (
        <div className="absolute top-0 left-0 w-full h-[420px] overflow-hidden -z-0 opacity-20 pointer-events-none">
          <img src={heroBg} alt="Hero Banner" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#07050E]/80 to-[#07050E]" />
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 pt-6 sm:pt-10 relative z-10">
        {/* Creator Profile / Hero Section */}
        <section className="flex flex-col items-center text-center">
          {/* Circular Frame Profile Image with Glowing Neon Gradient Border */}
          <div className="relative group">
            <div className="absolute -inset-1.5 rounded-full bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 blur-lg opacity-75 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-full p-1.5 bg-gradient-to-tr from-violet-600 via-fuchsia-500 to-pink-500 shadow-2xl">
              <img
                src={profileImg}
                alt={creatorName}
                className="w-full h-full rounded-full object-cover border-4 border-[#07050E] shadow-inner bg-slate-900"
              />
            </div>
          </div>

          {/* Brand Name */}
          <h1 className="mt-5 text-3xl sm:text-5xl font-black text-white tracking-tight">
            {creatorName}
          </h1>

          {/* Subtitle */}
          <p className="mt-2 text-sm sm:text-base font-bold bg-gradient-to-r from-fuchsia-400 via-pink-400 to-violet-300 bg-clip-text text-transparent tracking-wide">
            {subtitle}
          </p>

          {/* Bio / Description */}
          <p className="mt-3 text-xs sm:text-sm font-medium text-slate-300 max-w-xl leading-relaxed">
            {bio}
          </p>

          {/* WhatsApp Button */}
          {isWaVisible && (
            <div className="mt-6 flex flex-col items-center gap-2">
              <a
                href={`https://wa.me/${cleanWhatsAppNumber}?text=Hi%20Ghanshyam,%20I%20want%20to%20know%20more%20about%20your%20courses!`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-full bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 hover:text-emerald-200 text-xs sm:text-sm font-extrabold shadow-lg shadow-emerald-500/15 hover:shadow-emerald-500/25 transition-all transform active:scale-95 group cursor-pointer"
              >
                {renderWaIcon()}
                <span className="tracking-wide">{waButtonText}</span>
              </a>
              <span className="text-[11px] text-slate-400 font-medium">
                Direct WhatsApp assistance & instant guidance
              </span>
            </div>
          )}

          {/* Value Badges */}
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-xs text-slate-300 font-semibold">
            <div className="flex items-center gap-1.5 bg-white/[0.04] border border-white/[0.08] px-3.5 py-1.5 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Industry-Grade Skills</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/[0.04] border border-white/[0.08] px-3.5 py-1.5 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5 text-violet-400" />
              <span>Instant QR Payment</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/[0.04] border border-white/[0.08] px-3.5 py-1.5 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5 text-pink-400" />
              <span>Direct WhatsApp Course Delivery</span>
            </div>
          </div>
        </section>

        {/* Section: MY COURSES */}
        <section id="courses-section" className="mt-14 sm:mt-18 pt-8 border-t border-white/[0.08] scroll-mt-20">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
            <div>
              <div className="flex items-center gap-2 text-fuchsia-400 font-bold text-xs uppercase tracking-widest mb-1">
                <GraduationCap className="w-4 h-4" />
                <span>Premium Curriculum</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                MY COURSES
              </h2>
            </div>
            <div className="text-xs text-slate-400 font-medium">
              Showing <span className="font-bold text-white">{products.length}</span> Published Course{products.length === 1 ? '' : 's'}
            </div>
          </div>

          {/* Loading State */}
          {isLoading ? (
            <div className="py-20 flex flex-col items-center justify-center text-center">
              <RefreshCw className="w-8 h-8 text-fuchsia-500 animate-spin mb-3" />
              <p className="text-xs font-semibold text-slate-400">Loading courses...</p>
            </div>
          ) : products.length === 0 ? (
            <div className="py-16 text-center bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8">
              <GraduationCap className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Courses Available Yet</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Check back soon or message on WhatsApp for upcoming course release dates.
              </p>
            </div>
          ) : (
            /* Modern Responsive Grid (Courses Only) */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onBuyNow={(prod) => setSelectedProduct(prod)}
                  onViewDetails={(slug) => navigate(`/product/${slug}`)}
                />
              ))}
            </div>
          )}
        </section>

        {/* Support Section */}
        <section id="support-section" className="mt-16 pt-10 border-t border-white/[0.08] scroll-mt-20">
          <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] p-6 sm:p-10 text-center relative overflow-hidden shadow-2xl max-w-2xl mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-7 h-7" />
            </div>

            <span className="text-[11px] uppercase tracking-wider font-extrabold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              Need Help?
            </span>

            <h3 className="text-xl sm:text-2xl font-black text-white mt-3">
              Chat with us on WhatsApp
            </h3>

            <p className="mt-2 text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              For course/payment/support queries:
            </p>

            <div className="mt-3 p-3 bg-white/[0.03] rounded-2xl border border-white/[0.06] inline-block">
              <span className="text-[11px] text-slate-400 block font-medium">WhatsApp:</span>
              <span className="font-mono font-bold text-emerald-400 text-sm sm:text-base">
                +91 7976028995
              </span>
            </div>

            <div className="mt-6">
              <a
                href="https://wa.me/917976028995"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-emerald-500/25 transition-all transform active:scale-95 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-slate-950" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-20 pt-8 border-t border-white/[0.08] text-center text-xs text-slate-400">
          <p>© {new Date().getFullYear()} {creatorName}. All rights reserved.</p>
          <p className="mt-1 text-[11px] text-slate-500">
            {subtitle}
          </p>
        </footer>
      </main>

      {/* Checkout Modal */}
      {selectedProduct && (
        <CheckoutModal
          product={selectedProduct}
          isOpen={Boolean(selectedProduct)}
          onClose={() => setSelectedProduct(null)}
          onOrderCreated={(orderId) => {
            setSelectedProduct(null);
            navigate(`/payment/${orderId}`);
          }}
        />
      )}
    </div>
  );
};
