import React, { useState, useEffect } from 'react';
import { Product } from '../types.ts';
import { CheckoutModal } from '../components/CheckoutModal.tsx';
import {
  ArrowLeft,
  PlayCircle,
  CheckCircle2,
  Clock,
  BookOpen,
  User,
  ShieldCheck,
  MessageCircle,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';

interface ProductDetailPageProps {
  slug: string;
  navigate: (path: string) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ slug, navigate }) => {
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  useEffect(() => {
    async function fetchProduct() {
      try {
        setIsLoading(true);
        const res = await fetch(`/api/products/${slug}`);
        if (!res.ok) {
          throw new Error('Course not found or currently unavailable');
        }
        const data = await res.json();
        setProduct(data);
      } catch (err: any) {
        setError(err.message || 'Failed to load course');
      } finally {
        setIsLoading(false);
      }
    }
    fetchProduct();
  }, [slug]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-8 h-8 border-3 border-fuchsia-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-400">Loading course details...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-[#120F1F] rounded-3xl p-8 border border-white/[0.1] text-center shadow-xl">
          <h2 className="text-lg font-bold text-white">Course Not Found</h2>
          <p className="text-xs text-slate-400 mt-2 mb-6">
            The course you are looking for does not exist or has been updated.
          </p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-bold hover:shadow-lg transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Courses</span>
          </button>
        </div>
      </div>
    );
  }

  const discount =
    product.discountPercentage ||
    (product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 75);

  const defaultLearnings = [
    'Complete practical step-by-step implementation guide',
    'Official Cloud API & setup without recurring platform fees',
    'Automated lead capture, interactive buttons, and instant FAQ replies',
    'Broadcast campaigns with high deliverability rates',
    'Real-world automation workflows, templates and integration scripts',
    'Customer follow-ups, payment verification & automated digital delivery',
  ];

  const whatsappSupportUrl = `https://wa.me/917976028995?text=Hi%20Ghanshyam,%20I%20have%20a%20question%20about%20the%20${encodeURIComponent(product.title)}`;

  return (
    <div className="min-h-screen bg-[#07050E] text-slate-100 pb-28">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-violet-600/20 via-fuchsia-600/15 to-transparent blur-[130px] pointer-events-none -z-0" />

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 relative z-10">
        {/* Top Breadcrumb */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white transition-colors p-1 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Courses</span>
          </button>

          <span className="text-[11px] font-bold text-fuchsia-400 uppercase tracking-wider bg-fuchsia-500/10 border border-fuchsia-500/20 px-3 py-1 rounded-full">
            Video Masterclass
          </span>
        </div>

        {/* Two-Column Grid: Left (Content) / Right (Pricing & CTA) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Main Section (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            {/* 1. Large Course Thumbnail */}
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl overflow-hidden">
              <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
                <img
                  src={product.thumbnailUrl}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#120F1F] via-transparent to-black/30" />

                {/* Offer Badge only if enabled by admin */}
                {product.showBadge && product.badgeText && (
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-black text-xs px-3 py-1.5 rounded-xl shadow-lg tracking-wider uppercase">
                    {product.badgeText}
                  </div>
                )}
              </div>

              {/* Title & Short Summary */}
              <div className="p-6 sm:p-8">
                <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-snug">
                  {product.title}
                </h1>

                <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
                  {product.shortDescription}
                </p>
              </div>
            </div>

            {/* 2. What You'll Learn Section */}
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-fuchsia-400" />
                <span>What You'll Learn</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                {defaultLearnings.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2.5 p-3 rounded-2xl bg-white/[0.02] border border-white/[0.05]"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-xs sm:text-sm text-slate-200 leading-snug font-medium">
                      {item}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Course Description & Full Curriculum */}
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight mb-4">
                Course Curriculum & Overview
              </h2>

              <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-300 whitespace-pre-line leading-relaxed">
                {product.description}
              </div>

              {/* Lesson Modules List */}
              {product.lessons && product.lessons.length > 0 && (
                <div className="mt-8 pt-6 border-t border-white/[0.08]">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 text-fuchsia-400">
                    Structured Video Modules ({product.lessons.length})
                  </h3>

                  <div className="space-y-3">
                    {product.lessons.map((lesson, idx) => (
                      <div
                        key={lesson.id}
                        className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center font-bold text-xs shrink-0">
                            {idx + 1}
                          </div>
                          <div>
                            <h4 className="text-xs sm:text-sm font-bold text-white">
                              {lesson.title}
                            </h4>
                            {lesson.description && (
                              <p className="text-[11px] text-slate-400 mt-0.5">
                                {lesson.description}
                              </p>
                            )}
                          </div>
                        </div>

                        {lesson.duration && (
                          <span className="text-[11px] font-mono font-bold text-slate-400 shrink-0">
                            {lesson.duration}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* 4. Instructor Information */}
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
              <h2 className="text-lg font-black text-white tracking-tight mb-4">
                About the Instructor
              </h2>

              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                <div className="w-20 h-20 rounded-full p-1 bg-gradient-to-tr from-violet-600 via-fuchsia-500 to-pink-500 shadow-xl shrink-0 overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=400&q=80"
                    alt="Instructor"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>

                <div>
                  <h3 className="text-base font-extrabold text-white">GHANSHYAM SKILLS</h3>
                  <p className="text-xs font-bold text-fuchsia-400">Founder & Tech Instructor</p>
                  <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                    Passionate digital educator empowering students, creators, and freelancers with real-world, high-income technology skills. Step-by-step guidance from zero to mastery.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Section / Sticky Sidebar (4 cols) */}
          <div className="lg:col-span-4 sticky top-24 space-y-4">
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.1] shadow-2xl p-6 sm:p-7 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-fuchsia-600/10 blur-2xl pointer-events-none" />

              <span className="text-[10px] uppercase font-bold tracking-wider text-fuchsia-400 block mb-1">
                Special Limited Offer
              </span>

              {/* Price Display */}
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  ₹{product.price}
                </span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-base text-slate-400 line-through">
                    ₹{product.originalPrice}
                  </span>
                )}
                {product.showBadge && product.badgeText && (
                  <span className="text-xs font-black text-pink-400 ml-auto bg-pink-500/15 border border-pink-500/30 px-2 py-0.5 rounded-lg uppercase">
                    {product.badgeText}
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 mb-6">
                One-time payment for complete lifetime access. Includes future updates and curriculum resources.
              </p>

              {/* Action Buttons: [ BUY NOW ] [ CHAT ON WHATSAPP ] */}
              <div className="space-y-3">
                <button
                  onClick={() => setIsCheckoutOpen(true)}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 active:scale-98 text-white font-black text-sm shadow-xl shadow-violet-600/35 hover:shadow-fuchsia-500/50 transition-all flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>BUY NOW</span>
                </button>

                <a
                  href={whatsappSupportUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-2xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 hover:border-emerald-400 text-emerald-300 hover:text-emerald-200 font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>CHAT ON WHATSAPP</span>
                </a>
              </div>

              {/* Security & Access Highlights */}
              <div className="mt-6 pt-5 border-t border-white/[0.08] space-y-2.5 text-xs text-slate-300 font-medium">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Instant access upon payment proof</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-fuchsia-400 shrink-0" />
                  <span>Lifetime access & free updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-violet-400 shrink-0" />
                  <span>Direct WhatsApp verified support</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <CheckoutModal
          product={product}
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          onOrderCreated={(orderId) => {
            setIsCheckoutOpen(false);
            navigate(`/payment/${orderId}`);
          }}
        />
      )}
    </div>
  );
};
