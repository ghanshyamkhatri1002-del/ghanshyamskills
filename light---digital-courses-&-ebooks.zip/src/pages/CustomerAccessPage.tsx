import React, { useState, useEffect } from 'react';
import {
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  PlayCircle,
  Video,
  Lock,
  ArrowLeft,
  Share2,
  Sparkles,
} from 'lucide-react';

interface CustomerAccessPageProps {
  token: string;
  navigate: (path: string) => void;
}

interface AccessPayload {
  access: {
    id: string;
    status: string;
    createdAt: string;
  };
  product: {
    id: string;
    type: 'course';
    title: string;
    thumbnailUrl: string;
    shortDescription: string;
    description: string;
    contentUrl?: string;
    lessons?: Array<{
      id: string;
      title: string;
      videoUrl: string;
      description: string;
      supportingFileUrl?: string;
      duration?: string;
    }>;
    hasDownloadableFile: boolean;
    fileName: string;
  };
  customer: {
    name: string;
    email: string;
  };
  order: {
    id: string;
    amount: number;
    createdAt: string;
  };
}

export const CustomerAccessPage: React.FC<CustomerAccessPageProps> = ({ token, navigate }) => {
  const [data, setData] = useState<AccessPayload | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    async function verifyAccess() {
      try {
        setIsLoading(true);
        const res = await fetch(`/api/access/${token}`);
        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || 'Access denied or invalid token');
        }
        const payload = await res.json();
        setData(payload);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    }
    verifyAccess();
  }, [token]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-8 h-8 border-3 border-fuchsia-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-400">Verifying secure access...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-[#120F1F] rounded-3xl p-8 border border-white/[0.08] text-center shadow-2xl">
          <div className="w-14 h-14 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white">Access Not Authorized</h2>
          <p className="text-xs text-slate-400 mt-2 mb-6 leading-relaxed">
            {error || 'This access link is invalid, expired, or pending admin verification.'}
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-bold hover:shadow-lg transition-all cursor-pointer"
          >
            Return to Courses
          </button>
        </div>
      </div>
    );
  }

  const { product, customer } = data;
  const courseUrl = product.contentUrl;

  return (
    <div className="min-h-screen bg-[#07050E] text-slate-100 pb-20">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-b from-violet-600/20 via-fuchsia-600/15 to-transparent blur-[120px] pointer-events-none -z-0" />

      {/* Main Container */}
      <main className="max-w-3xl mx-auto px-4 pt-6 sm:pt-8 relative z-10">
        {/* Navigation & Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Store</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white px-3 py-1.5 rounded-xl bg-white/[0.06] border border-white/[0.08] transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{copiedLink ? 'Link Copied!' : 'Share Access'}</span>
            </button>
          </div>
        </div>

        {/* Verification Success Banner */}
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center gap-3 mb-6">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div className="text-xs">
            <span className="font-bold text-white">Payment Verified & Access Unlocked! </span>
            <span className="text-slate-300">
              Welcome {customer.name}, your course access is now permanently active.
            </span>
          </div>
        </div>

        {/* Course Card */}
        <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl overflow-hidden p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row gap-6 items-start">
            <img
              src={product.thumbnailUrl}
              alt={product.title}
              className="w-full sm:w-48 aspect-video sm:aspect-square object-cover rounded-2xl border border-white/[0.1] shrink-0"
            />
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-fuchsia-400 block mb-1">
                Enrolled Course
              </span>
              <h1 className="text-xl sm:text-2xl font-black text-white leading-tight">
                {product.title}
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                {product.shortDescription}
              </p>

              {/* Direct Course Link CTA */}
              {courseUrl ? (
                <div className="mt-5 space-y-2">
                  <a
                    href={courseUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 text-white font-extrabold text-sm shadow-xl shadow-violet-600/30 transition-all cursor-pointer"
                  >
                    <span>OPEN COURSE NOW</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <p className="text-[11px] text-slate-400 font-mono break-all">
                    Direct Link: {courseUrl}
                  </p>
                </div>
              ) : (
                <p className="mt-4 text-xs text-slate-400">
                  Course link is configured and verified for your account.
                </p>
              )}
            </div>
          </div>

          {/* Curriculum */}
          {product.lessons && product.lessons.length > 0 && (
            <div className="mt-8 pt-6 border-t border-white/[0.08]">
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                <PlayCircle className="w-4 h-4 text-fuchsia-400" />
                <span>Course Lessons & Modules</span>
              </h3>
              <div className="space-y-2.5">
                {product.lessons.map((lesson, idx) => (
                  <div
                    key={lesson.id}
                    className="p-3.5 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-white/[0.06] text-fuchsia-400 font-bold flex items-center justify-center text-[11px]">
                        {idx + 1}
                      </span>
                      <div>
                        <p className="font-bold text-white">{lesson.title}</p>
                        {lesson.description && (
                          <p className="text-[11px] text-slate-400 line-clamp-1">{lesson.description}</p>
                        )}
                      </div>
                    </div>
                    {lesson.videoUrl && (
                      <a
                        href={lesson.videoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-fuchsia-400 hover:underline font-bold text-xs shrink-0 ml-3"
                      >
                        Watch
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
