import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { ShieldCheck, ArrowRight, Lock, Mail, KeyRound } from 'lucide-react';

interface AdminLoginPageProps {
  navigate: (path: string) => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ navigate }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('admin@ghanshyamskills.com');
  const [password, setPassword] = useState('admin123456');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Invalid credentials');
      }

      login(data.token, data.admin);
      navigate('/admin');
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const fillDemo = () => {
    setEmail('admin@ghanshyamskills.com');
    setPassword('admin123456');
    setErrorMessage('');
  };

  return (
    <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4 text-white relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-violet-600/15 blur-[140px] pointer-events-none" />

      <div className="max-w-md w-full bg-[#120F1F] rounded-3xl border border-white/[0.1] shadow-2xl p-8 relative z-10">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-500 text-white flex items-center justify-center mx-auto mb-3 font-black text-xl shadow-lg shadow-violet-500/25">
            GS
          </div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-fuchsia-400">
            Creator Administration
          </span>
          <h1 className="text-2xl font-black text-white tracking-tight mt-1">
            GHANSHYAM SKILLS
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Sign in to manage courses, verify payments & orders
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs rounded-xl font-semibold">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">Admin Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@ghanshyamskills.com"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.05] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-fuchsia-500 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.05] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-fuchsia-500 transition-all"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 disabled:opacity-50 text-white font-extrabold text-sm shadow-xl shadow-violet-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            {isLoading ? <span>Signing in...</span> : <span>Sign In to Dashboard</span>}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-white/[0.08] flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={fillDemo}
            className="text-fuchsia-400 hover:text-fuchsia-300 font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Fill Demo Credentials</span>
          </button>
          <button
            onClick={() => navigate('/')}
            className="text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Back to Store
          </button>
        </div>
      </div>
    </div>
  );
};
