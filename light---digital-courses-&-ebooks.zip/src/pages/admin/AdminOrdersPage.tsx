import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { Order, OrderStatus } from '../../types.ts';
import {
  CheckCircle2,
  XCircle,
  Eye,
  Clock,
  MessageCircle,
  Mail,
  ExternalLink,
  RefreshCw,
  X,
  FileImage,
  AlertCircle,
  Share2,
  Copy,
  Check,
  GraduationCap,
} from 'lucide-react';

interface AdminOrdersPageProps {
  navigate: (path: string) => void;
}

export const AdminOrdersPage: React.FC<AdminOrdersPageProps> = ({ navigate }) => {
  const { token } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<OrderStatus | 'ALL'>('ALL');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Rejection modal state
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState(
    'Payment screenshot could not be verified with our bank records. Please submit a valid payment screenshot with visible UTR number.'
  );

  // Approval result modal state
  const [approvalResult, setApprovalResult] = useState<{
    order: Order;
    secureAccessUrl: string;
  } | null>(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const fetchOrders = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/orders', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error('Failed to load orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [token]);

  const filteredOrders = orders.filter((o) => {
    if (filter === 'ALL') return true;
    if (filter === 'PAYMENT_SUBMITTED') {
      return o.status === 'PAYMENT_SUBMITTED' || o.status === 'PENDING';
    }
    return o.status === filter;
  });

  const handleApprove = async (orderId: string) => {
    setIsProcessing(true);
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setApprovalResult({
          order: data.order,
          secureAccessUrl: data.secureAccessUrl || data.destinationUrl,
        });
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(data.order);
        }
      } else {
        alert(data.error || 'Failed to approve order');
      }
    } catch (err) {
      console.error('Approve error:', err);
      alert('Error approving order');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!selectedOrder) return;
    setIsProcessing(true);
    try {
      const res = await fetch(`/api/admin/orders/${selectedOrder.id}/reject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ reason: rejectionReason }),
      });
      const data = await res.json();
      if (res.ok) {
        setOrders((prev) => prev.map((o) => (o.id === selectedOrder.id ? data.order : o)));
        setSelectedOrder(data.order);
        setIsRejectModalOpen(false);
      } else {
        alert(data.error || 'Failed to reject order');
      }
    } catch (err) {
      console.error('Reject error:', err);
      alert('Error rejecting order');
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'PAYMENT_SUBMITTED':
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            Verification Needed
          </span>
        );
      case 'APPROVED':
      case 'PAID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Approved
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-white/[0.06] text-slate-400 border border-white/[0.08]">
            Pending Payment
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#07050E] text-white pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-bold text-fuchsia-400">
              Orders & Verification
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Customer Orders
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Verify customer UPI payment screenshots and deliver direct course access.
            </p>
          </div>

          <button
            onClick={fetchOrders}
            className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-xs font-bold text-slate-300 hover:text-white border border-white/[0.08] transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Orders</span>
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="mt-6 flex items-center gap-2 overflow-x-auto pb-2">
          {(
            [
              { key: 'ALL', label: 'All Orders' },
              { key: 'PAYMENT_SUBMITTED', label: 'Pending Verification' },
              { key: 'APPROVED', label: 'Approved' },
              { key: 'REJECTED', label: 'Rejected' },
            ] as const
          ).map((tab) => {
            const count =
              tab.key === 'ALL'
                ? orders.length
                : orders.filter((o) => o.status === tab.key).length;
            const isActive = filter === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-600/25'
                    : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/[0.08] border border-white/[0.06]'
                }`}
              >
                {tab.label} ({count})
              </button>
            );
          })}
        </div>

        {/* Orders Table */}
        <div className="mt-6 bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl overflow-hidden">
          {isLoading ? (
            <div className="py-16 text-center text-slate-400">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-fuchsia-500" />
              <p className="text-xs font-semibold">Loading orders...</p>
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="py-16 text-center text-slate-400 text-xs font-medium">
              No orders found in this category.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.03] border-b border-white/[0.08] text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3.5 px-4">Order ID</th>
                    <th className="py-3.5 px-4">Customer</th>
                    <th className="py-3.5 px-4">Course</th>
                    <th className="py-3.5 px-4">Amount</th>
                    <th className="py-3.5 px-4">Proof</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4">Date</th>
                    <th className="py-3.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {filteredOrders.map((order) => {
                    const hasProof = Boolean(order.paymentSubmission?.screenshotUrl);
                    return (
                      <tr key={order.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-white whitespace-nowrap">
                          {order.id}
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-bold text-white">{order.customer.name}</div>
                          <div className="text-[11px] text-slate-400">{order.customer.email}</div>
                          <div className="text-[11px] font-bold text-emerald-400">
                            {order.customer.whatsappNumber}
                          </div>
                        </td>

                        <td className="py-3.5 px-4 max-w-[180px]">
                          <span className="font-bold text-white block truncate">
                            {order.product.title}
                          </span>
                          <span className="text-[10px] text-fuchsia-400 uppercase font-semibold">
                            Course
                          </span>
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap font-mono font-black text-white text-sm">
                          ₹{order.amount}
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {hasProof ? (
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-fuchsia-500/15 hover:bg-fuchsia-500/25 text-fuchsia-300 font-bold text-[11px] border border-fuchsia-500/30 transition-colors cursor-pointer"
                            >
                              <FileImage className="w-3.5 h-3.5" />
                              <span>View Proof</span>
                            </button>
                          ) : (
                            <span className="text-slate-500 italic text-[11px]">Not uploaded</span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {getStatusBadge(order.status)}
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap text-slate-400 text-[11px]">
                          {new Date(order.createdAt).toLocaleDateString([], {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </td>

                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
                          >
                            Review Order
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Order Review Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-[#120F1F] rounded-3xl shadow-2xl border border-white/[0.12] overflow-hidden max-h-[90vh] flex flex-col text-white">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-white/[0.08] flex items-center justify-between bg-white/[0.02]">
              <div className="flex items-center gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-fuchsia-400 block">
                    Order Verification
                  </span>
                  <h3 className="text-lg font-black text-white">
                    Order #{selectedOrder.id}
                  </h3>
                </div>
                {getStatusBadge(selectedOrder.status)}
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="w-8 h-8 rounded-full bg-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.15] flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Customer info & Product info grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] text-xs space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Customer Information
                  </span>
                  <div className="font-bold text-white text-sm">
                    {selectedOrder.customer.name}
                  </div>
                  <div className="text-slate-300 font-mono">{selectedOrder.customer.email}</div>
                  <div className="font-bold text-emerald-400">
                    {selectedOrder.customer.whatsappNumber}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] text-xs space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Course Purchased
                  </span>
                  <div className="font-bold text-white text-sm truncate">
                    {selectedOrder.product.title}
                  </div>
                  <div className="text-slate-400">Amount Paid: <span className="font-mono font-black text-fuchsia-400">₹{selectedOrder.amount}</span></div>
                  {selectedOrder.product.contentUrl && (
                    <div className="text-[11px] text-fuchsia-400 truncate font-mono">
                      Course Link: {selectedOrder.product.contentUrl}
                    </div>
                  )}
                </div>
              </div>

              {/* Payment Screenshot Preview */}
              <div>
                <span className="text-xs font-bold text-slate-300 block mb-2">
                  Uploaded Payment Screenshot
                </span>
                {selectedOrder.paymentSubmission?.screenshotUrl ? (
                  <div className="border border-white/[0.1] rounded-2xl p-2 bg-black/40 text-center">
                    <img
                      src={selectedOrder.paymentSubmission.screenshotUrl}
                      alt="Payment Proof"
                      className="max-h-96 mx-auto rounded-xl object-contain shadow-lg"
                    />
                    <div className="mt-2 flex items-center justify-between px-2 text-[11px] text-slate-400">
                      <span>Submitted: {new Date(selectedOrder.paymentSubmission.submittedAt).toLocaleString()}</span>
                      <a
                        href={selectedOrder.paymentSubmission.screenshotUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-fuchsia-400 hover:underline font-bold inline-flex items-center gap-1"
                      >
                        <span>Open Full Size</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 border border-dashed border-white/[0.1] rounded-2xl text-center text-slate-500 text-xs">
                    Customer has not uploaded a payment screenshot yet.
                  </div>
                )}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-5 border-t border-white/[0.08] bg-white/[0.02] flex items-center justify-between gap-3">
              <div className="text-xs text-slate-400">
                Status:{' '}
                <strong className="text-white uppercase">{selectedOrder.status}</strong>
              </div>

              <div className="flex items-center gap-2">
                {selectedOrder.status !== 'REJECTED' && (
                  <button
                    onClick={() => setIsRejectModalOpen(true)}
                    className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 font-bold text-xs transition-colors cursor-pointer"
                  >
                    Reject Payment
                  </button>
                )}

                {selectedOrder.status !== 'APPROVED' ? (
                  <button
                    onClick={() => handleApprove(selectedOrder.id)}
                    disabled={isProcessing}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>APPROVE PAYMENT</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      const courseUrl = selectedOrder.product.contentUrl;
                      const waMsg = `Hi ${selectedOrder.customer.name} 👋\n\nYour payment for "${selectedOrder.product.title}" has been successfully verified! ✅\n\nYour course access is now unlocked.\n\n🎓 Access Your Course Here:\n${courseUrl}\n\nThank you for learning with GHANSHYAM SKILLS! Build your future ❤️`;
                      window.open(
                        `https://wa.me/${selectedOrder.customer.whatsappNumber.replace(/\D/g, '')}?text=${encodeURIComponent(waMsg)}`,
                        '_blank'
                      );
                    }}
                    className="px-4 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-xs border border-emerald-500/30 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Send WhatsApp Link</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reject Payment Reason Modal */}
      {isRejectModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#120F1F] rounded-3xl p-6 border border-white/[0.12] text-white space-y-4">
            <h3 className="text-base font-bold text-white">Reject Payment & Notify Customer</h3>
            <p className="text-xs text-slate-300">
              Please specify the reason why the payment was rejected. This will be sent to the customer on WhatsApp.
            </p>

            <textarea
              rows={3}
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="w-full p-3 rounded-xl border border-white/[0.1] bg-white/[0.05] text-xs text-white focus:outline-none focus:border-rose-500"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white bg-white/[0.05] cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                disabled={isProcessing}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs shadow-md shadow-rose-600/30 cursor-pointer"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Approval Success Modal with WhatsApp Action */}
      {approvalResult && (() => {
        const courseUrl = approvalResult.order.product.contentUrl || approvalResult.secureAccessUrl;
        const waMessage = `Hi ${approvalResult.order.customer.name} 👋\n\nYour payment for "${approvalResult.order.product.title}" has been successfully verified! ✅\n\nYour course access is now unlocked.\n\n🎓 Access Your Course Here:\n${courseUrl}\n\nThank you for learning with GHANSHYAM SKILLS! Build your future ❤️`;

        return (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in zoom-in-95 duration-200">
            <div className="w-full max-w-lg bg-[#120F1F] rounded-3xl p-6 sm:p-8 shadow-2xl border border-emerald-500/40 text-center space-y-4 text-white">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 inline-block">
                Payment Verified & Course Access Unlocked!
              </span>
              <h3 className="text-xl font-black text-white">
                COURSE ACCESS IS READY
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed">
                Order #{approvalResult.order.id} for{' '}
                <strong className="text-white">{approvalResult.order.customer.name}</strong> has been approved.
              </p>

              {/* Course Info Box */}
              <div className="p-4 bg-white/[0.03] rounded-2xl border border-white/[0.08] text-left text-xs space-y-2">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Course:
                  </span>
                  <span className="font-bold text-white text-sm block">
                    {approvalResult.order.product.title}
                  </span>
                </div>

                {courseUrl && (
                  <div>
                    <span className="text-[10px] uppercase font-bold text-fuchsia-400 block mb-1">
                      Direct Course Link (Customer Destination):
                    </span>
                    <span className="font-mono text-fuchsia-300 break-all bg-black/40 p-2.5 rounded-xl border border-white/[0.08] block text-xs">
                      {courseUrl}
                    </span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-2">
                {courseUrl && (
                  <a
                    href={courseUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 text-white font-extrabold text-sm shadow-xl shadow-violet-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>OPEN COURSE</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <a
                  href={`https://wa.me/${approvalResult.order.customer.whatsappNumber.replace(
                    /\D/g,
                    ''
                  )}?text=${encodeURIComponent(waMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send WhatsApp Message to Customer</span>
                </a>

                <button
                  onClick={() => setApprovalResult(null)}
                  className="w-full py-2.5 px-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 font-bold text-xs transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
