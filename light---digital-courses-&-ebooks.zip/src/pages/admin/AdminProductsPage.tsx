import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { Product } from '../../types.ts';
import {
  PlusCircle,
  ExternalLink,
  GraduationCap,
  RefreshCw,
  Link as LinkIcon,
  Archive,
  AlertCircle,
  CheckCircle2,
  Trash2,
} from 'lucide-react';

interface AdminProductsPageProps {
  navigate: (path: string) => void;
}

export const AdminProductsPage: React.FC<AdminProductsPageProps> = ({ navigate }) => {
  const { token } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Delete Confirmation Modal State
  const [courseToDelete, setCourseToDelete] = useState<Product | null>(null);

  // Archive / Purchases Warning Modal State
  const [archiveModal, setArchiveModal] = useState<{
    id: string;
    title: string;
    message: string;
  } | null>(null);

  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/products', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: Product[] = await res.json();
        // Strictly courses only
        setProducts(data.filter((p) => p.type === 'course'));
      } else {
        setErrorMessage('Failed to load courses from database.');
      }
    } catch (err: any) {
      console.error('Failed to fetch courses:', err);
      setErrorMessage(err.message || 'Network error fetching courses.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [token]);

  const confirmDelete = async (id: string, force = false) => {
    setIsDeleting(true);
    setErrorMessage('');

    try {
      const url = `/api/admin/products/${id}${force ? '?force=true' : ''}`;
      const res = await fetch(url, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      let data: any = {};
      try {
        const text = await res.text();
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }

      if (res.status === 400 && data.hasPurchases) {
        // Course has orders: close standard delete modal and prompt for archiving
        const title = courseToDelete?.title || 'Selected Course';
        setCourseToDelete(null);
        setArchiveModal({
          id,
          title,
          message: data.message || 'This course has existing orders. You can archive it instead.',
        });
        return;
      }

      if (res.ok && data.success) {
        setProducts((prev) => prev.filter((p) => p.id !== id));
        setCourseToDelete(null);
        setArchiveModal(null);
        setSuccessMessage('Course deleted successfully.');
        setTimeout(() => setSuccessMessage(''), 4000);
        await fetchProducts();
      } else {
        setErrorMessage(data.error || data.message || 'Failed to delete course from database.');
      }
    } catch (err: any) {
      console.error('Delete error:', err);
      setErrorMessage(err.message || 'Something went wrong while deleting. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleArchive = async (id: string) => {
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/admin/products/${id}/archive`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      let data: any = {};
      try {
        const text = await res.text();
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }

      if (res.ok) {
        setArchiveModal(null);
        setSuccessMessage('Course archived successfully.');
        setTimeout(() => setSuccessMessage(''), 4000);
        await fetchProducts();
      } else {
        setErrorMessage(data.error || 'Failed to archive course.');
      }
    } catch (err: any) {
      console.error('Archive error:', err);
      setErrorMessage(err.message || 'Something went wrong. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07050E] text-white pb-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-bold text-fuchsia-400">
              Course Catalog
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Courses
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Manage, edit, publish, and delete courses on GHANSHYAM SKILLS.
            </p>
          </div>

          <button
            onClick={() => navigate('/admin/products/new')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-black text-xs shadow-lg shadow-violet-600/25 transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Add Course</span>
          </button>
        </div>

        {/* Notifications */}
        {successMessage && (
          <div className="mt-4 p-3.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold rounded-2xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mt-4 p-3.5 bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold rounded-2xl flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Courses Table */}
        <div className="mt-6 bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl overflow-hidden">
          {isLoading ? (
            <div className="py-16 text-center text-slate-400">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-fuchsia-500" />
              <p className="text-xs font-semibold">Loading courses...</p>
            </div>
          ) : products.length === 0 ? (
            <div className="py-16 text-center text-slate-400">
              <GraduationCap className="w-12 h-12 text-slate-500 mx-auto mb-3" />
              <p className="text-sm font-bold text-white">No courses created yet</p>
              <button
                onClick={() => navigate('/admin/products/new')}
                className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-bold"
              >
                + Add Course
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.03] border-b border-white/[0.08] text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3.5 px-5">Course Name</th>
                    <th className="py-3.5 px-5">COURSE LINK</th>
                    <th className="py-3.5 px-5">PRICE</th>
                    <th className="py-3.5 px-5">STATUS</th>
                    <th className="py-3.5 px-5 text-right">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {products.map((product) => (
                    <tr key={product.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Course Title & Thumbnail */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-3.5">
                          <img
                            src={product.thumbnailUrl}
                            alt={product.title}
                            className="w-16 h-10 object-cover rounded-lg border border-white/[0.1] shrink-0"
                          />
                          <div className="min-w-0">
                            <span className="font-bold text-white block text-sm truncate max-w-xs sm:max-w-md">
                              {product.title}
                            </span>
                            {product.showBadge && product.badgeText && (
                              <span className="inline-block mt-0.5 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-pink-500/20 text-pink-300 border border-pink-500/30">
                                {product.badgeText}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Course Link */}
                      <td className="py-4 px-5">
                        {product.contentUrl ? (
                          <a
                            href={product.contentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-fuchsia-400 hover:text-fuchsia-300 font-mono text-[11px] max-w-[200px] truncate"
                          >
                            <LinkIcon className="w-3 h-3 shrink-0" />
                            <span className="truncate">{product.contentUrl}</span>
                          </a>
                        ) : (
                          <span className="text-slate-500 italic">No link set</span>
                        )}
                      </td>

                      {/* Price */}
                      <td className="py-4 px-5 font-mono">
                        <span className="font-extrabold text-white text-sm">₹{product.price}</span>
                        {product.originalPrice && product.originalPrice > product.price && (
                          <span className="text-slate-500 line-through ml-1.5 text-xs">
                            ₹{product.originalPrice}
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-4 px-5">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                            product.status === 'active'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : product.status === 'archived'
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-white/[0.06] text-slate-400 border border-white/[0.08]'
                          }`}
                        >
                          {product.status === 'active'
                            ? 'Published'
                            : product.status === 'archived'
                            ? 'Archived'
                            : 'Draft'}
                        </span>
                      </td>

                      {/* Actions: [Open] [Edit] [Delete] */}
                      <td className="py-4 px-5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => navigate(`/product/${product.slug}`)}
                            className="px-2.5 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-200 hover:text-white font-bold text-xs transition-colors cursor-pointer"
                            title="Open public course page"
                          >
                            Open
                          </button>
                          <button
                            onClick={() => navigate(`/admin/products/edit/${product.id}`)}
                            className="px-2.5 py-1.5 rounded-lg bg-fuchsia-500/15 hover:bg-fuchsia-500/25 text-fuchsia-300 hover:text-fuchsia-200 font-bold text-xs border border-fuchsia-500/30 transition-colors cursor-pointer"
                            title="Edit course"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => setCourseToDelete(product)}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 font-bold text-xs border border-rose-500/20 transition-colors cursor-pointer"
                            title="Delete course"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Confirmation Modal: Delete Course */}
      {courseToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div
            className="bg-[#120F1F] rounded-3xl border border-white/[0.12] p-6 sm:p-7 max-w-md w-full shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/15 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Delete this course?</h3>
                <p className="text-[11px] text-slate-400">This action will permanently delete the course.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-white/[0.02] p-3 rounded-xl border border-white/[0.06]">
              Are you sure you want to delete <strong className="text-white">"{courseToDelete.title}"</strong>?
              It will be permanently removed from the database and the public store.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setCourseToDelete(null)}
                className="px-4 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isDeleting}
                onClick={() => confirmDelete(courseToDelete.id)}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs shadow-lg shadow-rose-600/30 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <span>Delete Course</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Archive / Existing Orders Modal */}
      {archiveModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div
            className="bg-[#120F1F] rounded-3xl border border-white/[0.12] p-6 sm:p-7 max-w-md w-full shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 text-amber-400">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/15 flex items-center justify-center shrink-0">
                <AlertCircle className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Course Has Existing Orders</h3>
                <p className="text-[11px] text-slate-400">Past student orders exist for this course.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-white/[0.02] p-3 rounded-xl border border-white/[0.06]">
              This course has existing orders. You can archive it instead so existing students retain access, or force delete it.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
              <button
                disabled={isDeleting}
                onClick={() => handleArchive(archiveModal.id)}
                className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>Archive Course</span>
              </button>

              <button
                disabled={isDeleting}
                onClick={() => confirmDelete(archiveModal.id, true)}
                className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold text-xs transition-colors cursor-pointer"
              >
                Force Delete
              </button>

              <button
                disabled={isDeleting}
                onClick={() => setArchiveModal(null)}
                className="w-full sm:w-auto py-2.5 px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-400 font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
