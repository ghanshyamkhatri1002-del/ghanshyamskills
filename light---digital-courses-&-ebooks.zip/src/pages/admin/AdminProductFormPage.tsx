import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { Product, Lesson } from '../../types.ts';
import { ImageUpload } from '../../components/ImageUpload.tsx';
import { ContentUpload } from '../../components/ContentUpload.tsx';
import {
  ArrowLeft,
  GraduationCap,
  Plus,
  Trash2,
  RefreshCw,
  Save,
  Sparkles,
  Tag,
  Palette,
  CheckCircle2,
} from 'lucide-react';

interface AdminProductFormPageProps {
  productId?: string;
  navigate: (path: string) => void;
}

export const AdminProductFormPage: React.FC<AdminProductFormPageProps> = ({
  productId,
  navigate,
}) => {
  const { token } = useAuth();
  const isEditing = Boolean(productId);

  // Course fields
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [title, setTitle] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [discountPercentage, setDiscountPercentage] = useState('');

  // Offer Badge - strictly admin controlled
  const [showBadge, setShowBadge] = useState(false);
  const [badgeText, setBadgeText] = useState('75% OFF');
  const [badgeBgColor, setBadgeBgColor] = useState('#ec4899');
  const [badgeTextColor, setBadgeTextColor] = useState('#ffffff');
  const [badgePosition, setBadgePosition] = useState<'top-right' | 'top-left'>('top-right');

  const [contentUrl, setContentUrl] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [status, setStatus] = useState<'active' | 'draft' | 'archived'>('active');
  const [lessons, setLessons] = useState<Lesson[]>([]);

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (productId) {
      async function loadExisting() {
        try {
          setIsLoading(true);
          const res = await fetch('/api/admin/products', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (res.ok) {
            const list: Product[] = await res.json();
            const found = list.find((p) => p.id === productId);
            if (found) {
              setThumbnailUrl(found.thumbnailUrl || '');
              setTitle(found.title || '');
              setShortDescription(found.shortDescription || '');
              setDescription(found.description || '');
              setPrice(found.price ? found.price.toString() : '');
              setOriginalPrice(found.originalPrice ? found.originalPrice.toString() : '');
              setDiscountPercentage(found.discountPercentage ? found.discountPercentage.toString() : '');
              setShowBadge(Boolean(found.showBadge));
              setBadgeText(found.badgeText || '75% OFF');
              setBadgeBgColor(found.badgeBgColor || '#ec4899');
              setBadgeTextColor(found.badgeTextColor || '#ffffff');
              setBadgePosition(found.badgePosition || 'top-right');
              setContentUrl(found.contentUrl || '');
              setFileUrl(found.fileUrl || '');
              setFileName(found.fileName || '');
              setStatus(found.status || 'active');
              setLessons(found.lessons || []);
            }
          }
        } catch (err: any) {
          console.error('Error fetching course:', err);
          setErrorMessage('Failed to load course details.');
        } finally {
          setIsLoading(false);
        }
      }
      loadExisting();
    }
  }, [productId, token]);

  const handleAddLesson = () => {
    const newLesson: Lesson = {
      id: 'les_' + Math.random().toString(36).substring(2, 8),
      title: `Module ${lessons.length + 1}: `,
      videoUrl: contentUrl || '',
      description: '',
      duration: '25 mins',
    };
    setLessons([...lessons, newLesson]);
  };

  const handleRemoveLesson = (index: number) => {
    setLessons(lessons.filter((_, i) => i !== index));
  };

  const handleLessonChange = (index: number, field: keyof Lesson, value: string) => {
    const updated = [...lessons];
    updated[index] = { ...updated[index], [field]: value };
    setLessons(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!thumbnailUrl.trim()) {
      setErrorMessage('Please upload a course thumbnail image.');
      return;
    }
    if (!title.trim()) {
      setErrorMessage('Please enter the course title.');
      return;
    }
    if (!shortDescription.trim()) {
      setErrorMessage('Please enter a short description.');
      return;
    }
    if (!price || Number(price) <= 0) {
      setErrorMessage('Please enter a valid course offer price.');
      return;
    }

    if (!contentUrl.trim() && !fileUrl.trim() && lessons.length === 0) {
      setErrorMessage('Please provide either a Course URL link or upload course content.');
      return;
    }

    setIsSaving(true);

    try {
      const calculatedDiscount =
        discountPercentage ? Number(discountPercentage) :
        originalPrice && Number(originalPrice) > Number(price)
          ? Math.round(((Number(originalPrice) - Number(price)) / Number(originalPrice)) * 100)
          : undefined;

      const payload = {
        type: 'course',
        thumbnailUrl: thumbnailUrl.trim(),
        title: title.trim(),
        shortDescription: shortDescription.trim(),
        description: description.trim() || shortDescription.trim(),
        price: Number(price),
        originalPrice: originalPrice ? Number(originalPrice) : undefined,
        discountPercentage: calculatedDiscount,
        showBadge: Boolean(showBadge),
        badgeText: showBadge ? badgeText.trim() : undefined,
        badgeBgColor: showBadge ? badgeBgColor : undefined,
        badgeTextColor: showBadge ? badgeTextColor : undefined,
        badgePosition: showBadge ? badgePosition : undefined,
        contentUrl: contentUrl.trim(),
        fileUrl: fileUrl.trim(),
        fileName: fileName.trim(),
        status,
        lessons,
      };

      const url = isEditing ? `/api/admin/products/${productId}` : '/api/admin/products';
      const method = isEditing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      let data: any = {};
      try {
        const text = await res.text();
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }

      if (!res.ok) {
        throw new Error(data.error || data.message || 'Failed to save course');
      }

      navigate('/admin/products');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error saving course. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <RefreshCw className="w-6 h-6 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07050E] text-white pb-24">
      <main className="max-w-3xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        <button
          onClick={() => navigate('/admin/products')}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white mb-4 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Courses</span>
        </button>

        <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
          <div className="pb-6 border-b border-white/[0.08]">
            <span className="text-[11px] uppercase font-bold tracking-wider text-fuchsia-400">
              {isEditing ? 'Course Editor' : 'Add New Course'}
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1">
              {isEditing ? `Edit: ${title || 'Course'}` : 'New Course'}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Configure course details, thumbnail, offer pricing, badge, and access links.
            </p>
          </div>

          {errorMessage && (
            <div className="mt-4 p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-6">
            {/* 1. Real Thumbnail Upload Component */}
            <div>
              <ImageUpload
                label="Course Thumbnail Image *"
                value={thumbnailUrl}
                onChange={(url) => setThumbnailUrl(url)}
                uploadEndpoint="/api/admin/upload/thumbnail"
                token={token || ''}
                helperText="Upload 16:9 banner image (PNG, JPG, WEBP up to 10MB)."
              />
            </div>

            {/* 2. Course Title */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Course Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. WhatsApp Automation Masterclass"
                className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-fuchsia-500 font-bold"
              />
            </div>

            {/* 3. Short Description */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Short Description *
              </label>
              <textarea
                required
                rows={2}
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
                placeholder="e.g. Learn WhatsApp Automation practically from beginner to advanced implementation."
                className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
              />
            </div>

            {/* 4. Pricing (Dynamic - no hardcoding) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Offer Price (₹) *
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">₹</span>
                  <input
                    type="number"
                    required
                    min="1"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="21"
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-fuchsia-500 font-mono font-bold"
                  />
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Amount charged to students during checkout
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Original Price (₹) (Optional Strikethrough)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">₹</span>
                  <input
                    type="number"
                    min="1"
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(e.target.value)}
                    placeholder="499"
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-fuchsia-500 font-mono"
                  />
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Displayed as strikethrough next to offer price
                </span>
              </div>
            </div>

            {/* 5. OFFER BADGE - STRICTLY ADMIN CONTROLLED */}
            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/[0.08] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Tag className="w-4 h-4 text-pink-400" />
                    <span>Offer Badge</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Control whether an offer/discount badge appears on the course card.
                  </p>
                </div>

                {/* Show Offer Badge Toggle: [ ON / OFF ] */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-300">
                    {showBadge ? 'ON' : 'OFF'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowBadge(!showBadge)}
                    className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                      showBadge ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600' : 'bg-white/[0.1]'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                        showBadge ? 'translate-x-6' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Badge Details when ON */}
              {showBadge && (
                <div className="pt-4 border-t border-white/[0.06] space-y-4 animate-in fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        Badge Text
                      </label>
                      <input
                        type="text"
                        value={badgeText}
                        onChange={(e) => setBadgeText(e.target.value)}
                        placeholder="e.g. 99% OFF, LIMITED OFFER, ₹21 ONLY"
                        className="w-full px-4 py-2 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        Badge Position
                      </label>
                      <select
                        value={badgePosition}
                        onChange={(e) => setBadgePosition(e.target.value as 'top-right' | 'top-left')}
                        className="w-full px-4 py-2 rounded-xl border border-white/[0.1] bg-[#1a152d] text-white text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
                      >
                        <option value="top-right">Top Right</option>
                        <option value="top-left">Top Left</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        Badge Background Color
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={badgeBgColor}
                          onChange={(e) => setBadgeBgColor(e.target.value)}
                          className="w-9 h-9 rounded-lg border border-white/[0.1] bg-transparent cursor-pointer"
                        />
                        <input
                          type="text"
                          value={badgeBgColor}
                          onChange={(e) => setBadgeBgColor(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        Badge Text Color
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={badgeTextColor}
                          onChange={(e) => setBadgeTextColor(e.target.value)}
                          className="w-9 h-9 rounded-lg border border-white/[0.1] bg-transparent cursor-pointer"
                        />
                        <input
                          type="text"
                          value={badgeTextColor}
                          onChange={(e) => setBadgeTextColor(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Badge Preview */}
                  <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06] flex items-center justify-between">
                    <span className="text-xs text-slate-400 font-medium">Live Badge Preview:</span>
                    <span
                      style={{ backgroundColor: badgeBgColor, color: badgeTextColor }}
                      className="text-xs font-black px-2.5 py-1 rounded-xl shadow-md uppercase tracking-wider"
                    >
                      {badgeText || '75% OFF'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* 6. Course Content Link or File */}
            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/[0.08]">
              <ContentUpload
                type="course"
                contentUrl={contentUrl}
                fileUrl={fileUrl}
                fileName={fileName}
                onContentUrlChange={(url) => setContentUrl(url)}
                onFileUploadChange={(uploadedFileUrl, uploadedFileName) => {
                  setFileUrl(uploadedFileUrl);
                  setFileName(uploadedFileName);
                }}
                token={token}
              />
            </div>

            {/* 7. Full Description */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Full Description & What You'll Learn
              </label>
              <textarea
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What students will learn, curriculum breakdown, prerequisites..."
                className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
              />
            </div>

            {/* 8. Course Visibility Status */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Course Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'active' | 'draft' | 'archived')}
                className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-[#1a152d] text-white text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
              >
                <option value="active">Active / Published (Visible on Storefront)</option>
                <option value="draft">Draft / Unpublished (Hidden from Storefront)</option>
                <option value="archived">Archived</option>
              </select>
            </div>

            {/* Submit Bar: [Save Changes] */}
            <div className="pt-4 border-t border-white/[0.08] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/admin/products')}
                className="px-4 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-xs font-bold text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 disabled:opacity-50 text-white font-black text-xs shadow-lg shadow-violet-600/30 flex items-center gap-2 cursor-pointer transition-all"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving Changes...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};
