import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { Order } from '../../types.ts';
import {
  GraduationCap,
  ShoppingBag,
  Clock,
  CheckCircle2,
  PlusCircle,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  ExternalLink,
  Sparkles,
  BookOpen,
  FileCheck,
} from 'lucide-react';

interface AdminDashboardPageProps {
  navigate: (path: string) => void;
}

interface DashboardStats {
  totalProducts: number;
  publishedCourses?: number;
  draftCourses?: number;
  totalOrders: number;
  pendingPayments: number;
  approvedOrders: number;
  totalRevenue: number;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ navigate }) => {
  const { token, admin } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/dashboard', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data.stats);
        setRecentOrders(data.recentOrders || []);
      }
    } catch (err) {
      console.error('Failed to load dashboard:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchDashboardData();
    }
  }, [token]);

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'PAYMENT_SUBMITTED':
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            Verification Needed
          </span>
        );
      case 'APPROVED':
      case 'PAID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Approved
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-white/[0.06] text-slate-400 border border-white/[0.08]">
            Pending Payment
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#07050E] text-white pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {/* Top bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-bold text-fuchsia-400">
              Overview
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Welcome, {admin?.name || 'Ghanshyam'}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Manage your courses, verify UPI payments, and deliver access on GHANSHYAM SKILLS.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/admin/products/new')}
              className="flex items-center gap-1.5 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-violet-600/25 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>+ Add Course</span>
            </button>

            <button
              onClick={fetchDashboardData}
              className="p-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 hover:text-white border border-white/[0.08] transition-colors cursor-pointer"
              title="Refresh Dashboard"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Primary Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mt-6">
          {/* Total Revenue */}
          <div className="bg-[#120F1F] rounded-2xl p-5 border border-white/[0.08] shadow-xl col-span-2 sm:col-span-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400">Total Revenue</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white">
              ₹{stats ? stats.totalRevenue.toLocaleString() : '0'}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">From verified purchases</span>
          </div>

          {/* Total Courses */}
          <div className="bg-[#120F1F] rounded-2xl p-5 border border-white/[0.08] shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400">Total Courses</span>
              <div className="w-8 h-8 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center">
                <GraduationCap className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white">
              {stats ? stats.totalProducts : '0'}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">In your catalog</span>
          </div>

          {/* Published Courses */}
          <div className="bg-[#120F1F] rounded-2xl p-5 border border-white/[0.08] shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400">Published</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-emerald-400">
              {stats?.publishedCourses ?? stats?.totalProducts ?? '0'}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">Live on storefront</span>
          </div>

          {/* Draft Courses */}
          <div className="bg-[#120F1F] rounded-2xl p-5 border border-white/[0.08] shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400">Draft Courses</span>
              <div className="w-8 h-8 rounded-xl bg-slate-500/15 text-slate-400 flex items-center justify-center">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-slate-300">
              {stats?.draftCourses ?? '0'}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">Hidden drafts</span>
          </div>

          {/* Total Orders */}
          <div className="bg-[#120F1F] rounded-2xl p-5 border border-white/[0.08] shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-400">Total Orders</span>
              <div className="w-8 h-8 rounded-xl bg-pink-500/15 text-pink-400 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white">
              {stats ? stats.totalOrders : '0'}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">All-time student orders</span>
          </div>
        </div>

        {/* Quick Pending Verifications Banner */}
        {stats && stats.pendingPayments > 0 && (
          <div className="mt-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">
                  {stats.pendingPayments} payment screenshot{stats.pendingPayments === 1 ? '' : 's'} waiting for verification
                </h3>
                <p className="text-xs text-slate-300">
                  Customers are awaiting course access confirmation. Click to review screenshots.
                </p>
              </div>
            </div>

            <button
              onClick={() => navigate('/admin/orders')}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
            >
              Review Now
            </button>
          </div>
        )}

        {/* Recent Orders Section */}
        <div className="mt-8 bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-xl p-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
            <div>
              <h2 className="text-base font-bold text-white">Recent Orders</h2>
              <p className="text-xs text-slate-400">Latest student course orders and payment receipts</p>
            </div>
            <button
              onClick={() => navigate('/admin/orders')}
              className="text-xs font-bold text-fuchsia-400 hover:text-fuchsia-300 flex items-center gap-1 cursor-pointer"
            >
              <span>View all orders</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-white/[0.06]">
            {recentOrders.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">No orders yet.</div>
            ) : (
              recentOrders.map((order) => (
                <div key={order.id} className="py-3.5 flex items-center justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-white">{order.id}</span>
                      <span className="text-slate-500 text-xs">·</span>
                      <span className="font-bold text-xs text-slate-200">{order.customer.name}</span>
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {order.product.title} · <span className="font-semibold text-white">₹{order.amount}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    {getStatusBadge(order.status)}
                    <button
                      onClick={() => navigate('/admin/orders')}
                      className="text-xs font-bold text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] transition-colors cursor-pointer"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
