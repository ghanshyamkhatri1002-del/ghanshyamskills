import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { SiteSettings, WhatsAppLog, EmailLog } from '../../types.ts';
import {
  Save,
  Check,
  RefreshCw,
  MessageCircle,
  ExternalLink,
  Sparkles,
  Palette,
  QrCode,
  User,
  Camera,
  Trash2,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface AdminSettingsPageProps {
  navigate: (path: string) => void;
}

export const AdminSettingsPage: React.FC<AdminSettingsPageProps> = ({ navigate }) => {
  const { token } = useAuth();
  const [settings, setSettings] = useState<SiteSettings>({
    creatorName: 'GHANSHYAM SKILLS',
    subtitle: 'Learn Skills. Build Your Future.',
    creatorBio:
      'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.',
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&h=600&q=80',
    heroBackgroundImage: '',
    heroHeading: 'GHANSHYAM SKILLS',
    heroSubtitle: 'Learn Skills. Build Your Future.',
    heroDescription:
      'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.',
    heroCtaText: 'Chat on WhatsApp',
    whatsappNumber: '+91 7976028995',
    whatsappButtonText: '💬 Chat on WhatsApp',
    whatsappButtonIcon: 'message-circle',
    whatsappButtonVisible: true,
    supportWhatsappNumber: '+91 7976028995',
    upiId: '7976028995@upi',
    paymentInstructions:
      '1. Open any UPI app such as Google Pay, PhonePe or Paytm.\n2. Scan the QR code or enter the UPI ID manually.\n3. Pay the exact course amount.\n4. Take a screenshot of the successful payment.\n5. Upload the payment screenshot below.',
    paymentQrCode: '/uploads/public/default_qr.svg',
    bgTheme: 'dark-violet',
    accentColor: 'violet',
    primaryColor: '#8b5cf6',
    secondaryColor: '#d946ef',
    buttonColor: '#10b981',
    footerText: '© 2026 GHANSHYAM SKILLS. Learn Skills. Build Your Future.',
    whatsappEnabled: true,
    emailEnabled: true,
  });

  const [logs, setLogs] = useState<{ whatsapp: WhatsAppLog[]; email: EmailLog[] }>({
    whatsapp: [],
    email: [],
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'whatsapp' | 'payment' | 'theme'>('profile');

  // Upload states
  const [isUploadingProfile, setIsUploadingProfile] = useState(false);
  const [isUploadingHero, setIsUploadingHero] = useState(false);
  const [isUploadingQr, setIsUploadingQr] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const profileInputRef = useRef<HTMLInputElement>(null);
  const heroInputRef = useRef<HTMLInputElement>(null);
  const qrInputRef = useRef<HTMLInputElement>(null);

  const fetchSettingsAndLogs = async () => {
    try {
      setIsLoading(true);
      const [setRes, logsRes] = await Promise.all([
        fetch('/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch('/api/admin/notifications', {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (setRes.ok) {
        const data = await setRes.json();
        setSettings((prev) => ({
          ...prev,
          ...data,
          creatorName: data.creatorName || 'GHANSHYAM SKILLS',
          subtitle: data.subtitle || 'Learn Skills. Build Your Future.',
          creatorBio:
            data.creatorBio ||
            'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.',
          whatsappButtonText: data.whatsappButtonText || '💬 Chat on WhatsApp',
          whatsappButtonVisible: data.whatsappButtonVisible !== false,
          whatsappNumber: data.whatsappNumber || '+91 7976028995',
        }));
      }
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setLogs(logsData);
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSettingsAndLogs();
  }, [token]);

  const handleFileUpload = async (
    file: File,
    endpoint: string,
    setLoadingState: (val: boolean) => void,
    onSuccessUrl: (url: string) => void
  ) => {
    setUploadError('');
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (!allowed.includes(file.type.toLowerCase())) {
      setUploadError('Only JPG, PNG, WEBP, or SVG images are supported.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setUploadError('Image size exceeds 10 MB limit.');
      return;
    }

    try {
      setLoadingState(true);
      const formData = new FormData();
      formData.append('image', file);

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to upload image');
      }

      onSuccessUrl(data.url);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setUploadError(err.message || 'Image upload failed. Please try again.');
    } finally {
      setLoadingState(false);
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(settings),
      });

      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3500);
      } else {
        alert('Failed to save settings. Please try again.');
      }
    } catch (err) {
      console.error('Save error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <RefreshCw className="w-6 h-6 animate-spin text-fuchsia-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07050E] text-white pb-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div>
            <span className="text-[11px] uppercase tracking-wider font-bold text-fuchsia-400">
              Platform Configuration
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Settings & Branding
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Customize brand name, creator profile, WhatsApp number, hero background and payments.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-xs font-bold text-slate-300 hover:text-white border border-white/[0.08] transition-colors cursor-pointer"
            >
              <span>View Live Store</span>
              <ExternalLink className="w-3.5 h-3.5 text-fuchsia-400" />
            </button>
          </div>
        </div>

        {/* Global Save Status Banner */}
        {saveSuccess && (
          <div className="mt-4 p-3.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold rounded-2xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Settings saved successfully! Changes are live immediately on your public website.</span>
          </div>
        )}

        {uploadError && (
          <div className="mt-4 p-3.5 bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold rounded-2xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{uploadError}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="mt-6 flex flex-wrap gap-2 border-b border-white/[0.08] pb-3">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-600/30'
                : 'text-slate-400 hover:text-white bg-white/[0.04]'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile & Branding</span>
          </button>

          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'whatsapp'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-600/30'
                : 'text-slate-400 hover:text-white bg-white/[0.04]'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp & Chat</span>
          </button>

          <button
            onClick={() => setActiveTab('payment')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'payment'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-600/30'
                : 'text-slate-400 hover:text-white bg-white/[0.04]'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Payment & QR</span>
          </button>

          <button
            onClick={() => setActiveTab('theme')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'theme'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-600/30'
                : 'text-slate-400 hover:text-white bg-white/[0.04]'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Theme & Colors</span>
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-6 space-y-8">
          {/* TAB 1: Profile & Branding */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8 space-y-6">
                <div className="flex items-center gap-2.5 pb-4 border-b border-white/[0.08]">
                  <div className="w-8 h-8 rounded-xl bg-fuchsia-500/15 text-fuchsia-400 flex items-center justify-center font-bold">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">Profile & Branding</h2>
                    <p className="text-xs text-slate-400">
                      Manage creator photo, hero background, and brand identity
                    </p>
                  </div>
                </div>

                {/* 1. Profile Image Editing System */}
                <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div>
                      <h3 className="text-sm font-bold text-white">Profile Image</h3>
                      <p className="text-[11px] text-slate-400">
                        Recommended profile image: 500x500 or higher. Displayed in the glowing circular creator frame.
                      </p>
                    </div>
                    {settings.profileImage && (
                      <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </span>
                    )}
                  </div>

                  {/* Hidden Input for Profile */}
                  <input
                    type="file"
                    ref={profileInputRef}
                    accept="image/png, image/jpeg, image/jpg, image/webp"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(
                          e.target.files[0],
                          '/api/admin/upload/profile',
                          setIsUploadingProfile,
                          (url) => setSettings((s) => ({ ...s, profileImage: url }))
                        );
                      }
                    }}
                  />

                  {/* Profile Image Preview & Actions */}
                  <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                    {/* Current Image Preview */}
                    <div className="relative group shrink-0">
                      <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full p-1 bg-gradient-to-tr from-violet-600 via-fuchsia-500 to-pink-500 shadow-xl overflow-hidden flex items-center justify-center">
                        {settings.profileImage ? (
                          <img
                            src={settings.profileImage}
                            alt="Current Profile Preview"
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full rounded-full bg-[#1b172a] flex items-center justify-center text-slate-400">
                            <User className="w-10 h-10" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex-1 text-center sm:text-left space-y-2">
                      <div className="text-xs font-semibold text-slate-300">
                        {settings.profileImage ? (
                          <span className="font-mono text-[11px] text-slate-400 truncate block max-w-xs sm:max-w-md">
                            {settings.profileImage}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">No custom image uploaded yet</span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 pt-1">
                        <button
                          type="button"
                          disabled={isUploadingProfile}
                          onClick={() => profileInputRef.current?.click()}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-extrabold text-xs shadow-md shadow-violet-600/20 flex items-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                        >
                          <Camera className="w-3.5 h-3.5" />
                          <span>
                            {isUploadingProfile
                              ? 'Uploading...'
                              : settings.profileImage
                              ? 'Replace Image'
                              : 'Upload Image'}
                          </span>
                        </button>

                        {settings.profileImage && (
                          <button
                            type="button"
                            onClick={() => setSettings((s) => ({ ...s, profileImage: '' }))}
                            className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove Image</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Hero Background Editing System */}
                <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div>
                      <h3 className="text-sm font-bold text-white">Hero Background</h3>
                      <p className="text-[11px] text-slate-400">
                        Optional custom background image for the top creator hero section.
                      </p>
                    </div>
                    {settings.heroBackgroundImage && (
                      <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </span>
                    )}
                  </div>

                  {/* Hidden Input for Hero Background */}
                  <input
                    type="file"
                    ref={heroInputRef}
                    accept="image/png, image/jpeg, image/jpg, image/webp"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(
                          e.target.files[0],
                          '/api/admin/upload/hero-background',
                          setIsUploadingHero,
                          (url) => setSettings((s) => ({ ...s, heroBackgroundImage: url }))
                        );
                      }
                    }}
                  />

                  {/* Hero Background Preview & Actions */}
                  <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                    {/* Current Background Preview */}
                    <div className="w-full sm:w-48 aspect-video rounded-xl bg-[#1b172a] border border-white/[0.1] shadow-lg overflow-hidden shrink-0 flex items-center justify-center">
                      {settings.heroBackgroundImage ? (
                        <img
                          src={settings.heroBackgroundImage}
                          alt="Hero Background Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center p-4 text-slate-500">
                          <ImageIcon className="w-6 h-6 mb-1 text-slate-600" />
                          <span className="text-[10px] uppercase font-bold tracking-wider">Default Gradients</span>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex-1 text-center sm:text-left space-y-2">
                      <div className="text-xs font-semibold text-slate-300">
                        {settings.heroBackgroundImage ? (
                          <span className="font-mono text-[11px] text-slate-400 truncate block max-w-xs sm:max-w-md">
                            {settings.heroBackgroundImage}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-xs">
                            Storefront currently displays premium dark violet/magenta neon gradients.
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 pt-1">
                        <button
                          type="button"
                          disabled={isUploadingHero}
                          onClick={() => heroInputRef.current?.click()}
                          className="px-4 py-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-white border border-white/[0.12] font-bold text-xs flex items-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                        >
                          <Camera className="w-3.5 h-3.5 text-fuchsia-400" />
                          <span>
                            {isUploadingHero
                              ? 'Uploading...'
                              : settings.heroBackgroundImage
                              ? 'Replace Background'
                              : 'Upload Background'}
                          </span>
                        </button>

                        {settings.heroBackgroundImage && (
                          <button
                            type="button"
                            onClick={() => setSettings((s) => ({ ...s, heroBackgroundImage: '' }))}
                            className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove Background</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Brand Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Brand Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.creatorName}
                    onChange={(e) => setSettings({ ...settings, creatorName: e.target.value })}
                    placeholder="GHANSHYAM SKILLS"
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-fuchsia-500 font-bold"
                  />
                </div>

                {/* Subtitle */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Subtitle / Tagline *
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.subtitle}
                    onChange={(e) => setSettings({ ...settings, subtitle: e.target.value })}
                    placeholder="Learn Skills. Build Your Future."
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-fuchsia-500 font-semibold"
                  />
                </div>

                {/* Creator Bio */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Creator Bio / Hero Description *
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={settings.creatorBio}
                    onChange={(e) => setSettings({ ...settings, creatorBio: e.target.value })}
                    placeholder="Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance."
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: WhatsApp & Chat */}
          {activeTab === 'whatsapp' && (
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center gap-2.5 pb-4 border-b border-white/[0.08]">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">WhatsApp Button Configuration</h2>
                  <p className="text-xs text-slate-400">
                    Direct WhatsApp CTA link on mobile and desktop
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    WhatsApp Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.whatsappNumber}
                    onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
                    placeholder="+91 7976028995"
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 font-mono"
                  />
                  <span className="text-[10px] text-emerald-400 font-mono mt-1 block">
                    Target: https://wa.me/{settings.whatsappNumber.replace(/\D/g, '')}
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Button Text *
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.whatsappButtonText}
                    onChange={(e) => setSettings({ ...settings, whatsappButtonText: e.target.value })}
                    placeholder="💬 Chat on WhatsApp"
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-2">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="waVisible"
                    checked={settings.whatsappButtonVisible}
                    onChange={(e) => setSettings({ ...settings, whatsappButtonVisible: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 bg-white/[0.05] border-white/[0.1]"
                  />
                  <label htmlFor="waVisible" className="text-xs font-bold text-white cursor-pointer">
                    Show "Chat on WhatsApp" Button on Storefront
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Payment & QR Settings */}
          {activeTab === 'payment' && (
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center gap-2.5 pb-4 border-b border-white/[0.08]">
                <div className="w-8 h-8 rounded-xl bg-violet-500/15 text-violet-400 flex items-center justify-center font-bold">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Payment & UPI QR Configuration</h2>
                  <p className="text-xs text-slate-400">
                    UPI ID and QR code presented to students on the payment page
                  </p>
                </div>
              </div>

              {/* UPI ID */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  UPI ID (Virtual Payment Address) *
                </label>
                <input
                  type="text"
                  required
                  value={settings.upiId}
                  onChange={(e) => setSettings({ ...settings, upiId: e.target.value })}
                  placeholder="7976028995@upi"
                  className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-violet-500 font-mono font-bold"
                />
              </div>

              {/* QR Upload System */}
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Merchant QR Code</h3>
                  <span className="text-[11px] text-slate-400 font-mono">{settings.paymentQrCode}</span>
                </div>

                <input
                  type="file"
                  ref={qrInputRef}
                  accept="image/png, image/jpeg, image/jpg, image/webp, image/svg+xml"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileUpload(
                        e.target.files[0],
                        '/api/admin/upload/qr',
                        setIsUploadingQr,
                        (url) => setSettings((s) => ({ ...s, paymentQrCode: url }))
                      );
                    }
                  }}
                />

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-28 h-28 rounded-xl bg-white p-2 shrink-0 shadow-lg flex items-center justify-center">
                    <img
                      src={settings.paymentQrCode}
                      alt="UPI QR Code"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <button
                      type="button"
                      disabled={isUploadingQr}
                      onClick={() => qrInputRef.current?.click()}
                      className="px-4 py-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-white border border-white/[0.12] font-bold text-xs flex items-center gap-2 cursor-pointer transition-all"
                    >
                      <Camera className="w-3.5 h-3.5 text-violet-400" />
                      <span>{isUploadingQr ? 'Uploading QR...' : 'Replace QR Code Image'}</span>
                    </button>
                    <p className="text-[11px] text-slate-400 mt-2">
                      Upload your official PhonePe, Google Pay, or Paytm merchant QR code.
                    </p>
                  </div>
                </div>
              </div>

              {/* Payment Instructions */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Payment Instructions
                </label>
                <textarea
                  rows={4}
                  value={settings.paymentInstructions || ''}
                  onChange={(e) => setSettings({ ...settings, paymentInstructions: e.target.value })}
                  placeholder="Step-by-step payment instructions shown to students..."
                  className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>
          )}

          {/* TAB 4: Theme & Colors */}
          {activeTab === 'theme' && (
            <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center gap-2.5 pb-4 border-b border-white/[0.08]">
                <div className="w-8 h-8 rounded-xl bg-pink-500/15 text-pink-400 flex items-center justify-center font-bold">
                  <Palette className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Visual Style & Gradients</h2>
                  <p className="text-xs text-slate-400">
                    Premium dark background, electric violet, magenta, and neon gradients
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Background Gradient Theme
                  </label>
                  <select
                    value={settings.bgTheme || 'dark-violet'}
                    onChange={(e) => setSettings({ ...settings, bgTheme: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-[#1a152d] text-white text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
                  >
                    <option value="dark-violet">Dark Violet & Magenta (Recommended)</option>
                    <option value="deep-purple">Deep Purple & Neon Pink</option>
                    <option value="midnight-blue">Midnight Blue & Cyan</option>
                    <option value="black-gradient">Black Luxury Minimalist</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    Accent Color
                  </label>
                  <select
                    value={settings.accentColor || 'violet'}
                    onChange={(e) => setSettings({ ...settings, accentColor: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-white/[0.1] bg-[#1a152d] text-white text-xs sm:text-sm focus:outline-none focus:border-fuchsia-500"
                  >
                    <option value="violet">Electric Violet (#8b5cf6)</option>
                    <option value="fuchsia">Vibrant Fuchsia (#d946ef)</option>
                    <option value="pink">Neon Pink (#ec4899)</option>
                    <option value="cyan">Cyber Cyan (#06b6d4)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Sticky Bottom Save Bar */}
          <div className="sticky bottom-4 z-20 p-4 bg-[#120F1F]/95 backdrop-blur-xl rounded-2xl border border-white/[0.15] shadow-2xl flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">
              Changes take effect immediately on your public site.
            </span>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 disabled:opacity-50 text-white font-extrabold text-xs shadow-lg shadow-violet-600/30 flex items-center gap-2 transition-all cursor-pointer"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving Changes...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* WhatsApp Notification Logs */}
        <div className="mt-12 bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
          <h2 className="text-base font-bold text-white mb-2">Recent WhatsApp Logs</h2>
          <p className="text-xs text-slate-400 mb-4">
            Messages dispatched when admin approves orders
          </p>

          <div className="space-y-3">
            {logs.whatsapp.length === 0 ? (
              <p className="text-xs text-slate-500 italic">No WhatsApp notification logs yet.</p>
            ) : (
              logs.whatsapp.slice(0, 5).map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06] text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">To: {log.recipient}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(log.sentAt).toLocaleString()}
                    </span>
                  </div>
                  <pre className="text-[11px] font-mono text-slate-300 whitespace-pre-wrap bg-black/40 p-2.5 rounded-xl border border-white/[0.06]">
                    {log.message}
                  </pre>
                  {log.whatsappWebUrl && (
                    <a
                      href={log.whatsappWebUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-fuchsia-400 hover:underline font-bold"
                    >
                      <span>Open in WhatsApp</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
