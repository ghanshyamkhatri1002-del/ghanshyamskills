import React, { useState, useEffect, useRef } from 'react';
import { Order } from '../types.ts';
import {
  UploadCloud,
  CheckCircle2,
  Clock,
  ArrowRight,
  Copy,
  Check,
  AlertCircle,
  FileImage,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  PlayCircle,
  Sparkles,
} from 'lucide-react';

interface PaymentPageProps {
  orderId: string;
  navigate: (path: string) => void;
}

export const PaymentPage: React.FC<PaymentPageProps> = ({ orderId, navigate }) => {
  const [order, setOrder] = useState<Order | null>(null);
  const [paymentInfo, setPaymentInfo] = useState<{
    upiId: string;
    qrCodeUrl: string;
    supportWhatsapp: string;
    creatorName: string;
  } | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchOrder = async (quiet = false) => {
    try {
      if (!quiet) setIsLoading(true);
      const res = await fetch(`/api/orders/${orderId}`);
      if (!res.ok) {
        throw new Error('Order not found');
      }
      const data = await res.json();
      setOrder(data.order);
      setPaymentInfo(data.paymentInfo);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load order');
    } finally {
      if (!quiet) setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrder();
    // Poll order status every 4 seconds if payment is submitted to detect admin approval instantly
    const interval = setInterval(() => {
      fetchOrder(true);
    }, 4000);
    return () => clearInterval(interval);
  }, [orderId]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage('');
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];

    // Validate size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('Screenshot exceeds 10MB limit. Please upload a smaller image.');
      return;
    }

    // Validate type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      setErrorMessage('Only JPG, JPEG, PNG, or WEBP image formats are supported.');
      return;
    }

    setSelectedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
  };

  const handleRemoveScreenshot = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setErrorMessage('');
  };

  const handleCopyUpi = () => {
    if (!paymentInfo?.upiId) return;
    navigator.clipboard.writeText(paymentInfo.upiId);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setErrorMessage('Please select a payment screenshot first.');
      return;
    }

    setIsUploading(true);
    setErrorMessage('');

    try {
      const formData = new FormData();
      formData.append('screenshot', selectedFile);

      const res = await fetch(`/api/orders/${orderId}/submit-payment`, {
        method: 'POST',
        body: formData,
      });

      let data: any = {};
      try {
        const text = await res.text();
        data = text ? JSON.parse(text) : {};
      } catch {
        data = {};
      }

      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to submit payment screenshot. Please try again.');
      }

      setOrder(data.order);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to upload screenshot. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  if (isLoading && !order) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-8 h-8 border-3 border-fuchsia-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-semibold text-slate-400">Loading payment checkout...</p>
        </div>
      </div>
    );
  }

  if (!order || !paymentInfo) {
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-[#120F1F] rounded-3xl p-8 border border-white/[0.1] text-center shadow-xl">
          <h2 className="text-lg font-bold text-white">Order Not Found</h2>
          <p className="text-xs text-slate-400 mt-2 mb-6">
            Unable to find the requested order ({orderId}).
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-bold hover:shadow-lg transition-all cursor-pointer"
          >
            Go to Courses
          </button>
        </div>
      </div>
    );
  }

  const directCourseUrl =
    order.product.contentUrl ||
    (order.productAccess?.accessToken
      ? `${window.location.origin}/access/${order.productAccess.accessToken}`
      : '');

  // If order is APPROVED, show instant access view
  if (order.status === 'APPROVED') {
    return (
      <div className="min-h-screen bg-[#07050E] text-slate-100 py-10 px-4 flex items-center justify-center">
        <main className="max-w-md w-full bg-[#120F1F] rounded-3xl border border-emerald-500/30 shadow-2xl p-6 sm:p-8 text-center animate-in fade-in duration-300">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-emerald-500/40">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            Payment Verified & Approved
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-white mt-3">
            Access Unlocked!
          </h1>

          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Welcome aboard, <strong className="text-white">{order.customer.name}</strong>! Your payment has been confirmed by GHANSHYAM SKILLS.
          </p>

          {/* Product Box */}
          <div className="my-6 p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] text-left flex items-center gap-3">
            <img
              src={order.product.thumbnailUrl}
              alt={order.product.title}
              className="w-14 h-14 rounded-xl object-cover border border-white/[0.1] shrink-0"
            />
            <div className="min-w-0 flex-1">
              <span className="text-[10px] uppercase font-bold tracking-wider text-fuchsia-400 block">
                Enrolled Course
              </span>
              <h4 className="font-bold text-white text-xs truncate">{order.product.title}</h4>
              <p className="text-[11px] text-emerald-400 font-semibold mt-0.5">Lifetime Access Active</p>
            </div>
          </div>

          {/* Direct Course Link Button */}
          {directCourseUrl ? (
            <div className="space-y-3">
              <a
                href={directCourseUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 text-white font-extrabold text-sm shadow-xl shadow-violet-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>OPEN COURSE NOW</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <p className="text-[11px] text-slate-400 font-mono break-all bg-black/40 p-2.5 rounded-xl border border-white/[0.06]">
                {directCourseUrl}
              </p>
            </div>
          ) : (
            <p className="text-xs text-slate-400">Course link has been sent to your WhatsApp.</p>
          )}

          <div className="mt-6 pt-4 border-t border-white/[0.08]">
            <button
              onClick={() => navigate('/')}
              className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Back to GHANSHYAM SKILLS Store
            </button>
          </div>
        </main>
      </div>
    );
  }

  // If PAYMENT_SUBMITTED, show pending verification status
  if (order.status === 'PAYMENT_SUBMITTED') {
    return (
      <div className="min-h-screen bg-[#07050E] text-slate-100 py-10 px-4 flex items-center justify-center">
        <main className="max-w-md w-full bg-[#120F1F] rounded-3xl border border-amber-500/30 shadow-2xl p-6 sm:p-8 text-center animate-in fade-in duration-300">
          <div className="w-16 h-16 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/40">
            <Clock className="w-8 h-8 animate-pulse" />
          </div>

          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            Verification In Progress
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-white mt-3">
            Payment Screenshot Submitted
          </h1>

          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            Thank you! Your payment proof is being verified by admin. Once approved, your direct course access link will be sent to your WhatsApp and email.
          </p>

          {/* Order Details card */}
          <div className="my-6 p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] text-left text-xs space-y-2">
            <div className="flex justify-between py-1 border-b border-white/[0.06]">
              <span className="text-slate-400">Order ID:</span>
              <span className="font-mono font-bold text-white">{order.id}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/[0.06]">
              <span className="text-slate-400">Customer:</span>
              <span className="font-semibold text-white">{order.customer.name}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/[0.06]">
              <span className="text-slate-400">WhatsApp:</span>
              <span className="font-semibold text-white">{order.customer.whatsappNumber}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/[0.06]">
              <span className="text-slate-400">Course:</span>
              <span className="font-semibold text-white truncate max-w-[200px]">
                {order.product.title}
              </span>
            </div>
            <div className="flex justify-between pt-1">
              <span className="text-slate-400 font-bold">Total Amount:</span>
              <span className="font-black text-fuchsia-400 text-sm">₹{order.amount}</span>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => fetchOrder(false)}
              className="w-full py-3 px-4 rounded-2xl border border-white/[0.1] bg-white/[0.05] hover:bg-white/[0.1] text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Check Verification Status</span>
            </button>

            <a
              href={`https://wa.me/917976028995?text=Hi%20Ghanshyam,%20I%20have%20submitted%20payment%20for%20Order%20${order.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-2xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <span>Notify Admin on WhatsApp</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </main>
      </div>
    );
  }

  // Active QR Payment & Screenshot Upload View
  return (
    <div className="min-h-screen bg-[#07050E] text-slate-100 py-6 sm:py-10 px-4">
      <main className="max-w-md mx-auto">
        <div className="bg-[#120F1F] rounded-3xl border border-white/[0.08] shadow-2xl p-6 sm:p-8">
          {/* Header */}
          <div className="text-center pb-5 border-b border-white/[0.08]">
            <span className="text-[11px] font-bold uppercase tracking-wider text-fuchsia-400">
              UPI QR Payment
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-1">
              Scan & Pay ₹{order.amount}
            </h1>
            <p className="text-xs text-slate-300 mt-1">
              Pay using Google Pay, PhonePe, Paytm, or any UPI App
            </p>
          </div>

          {/* Order Summary Pill */}
          <div className="mt-4 p-3 bg-white/[0.03] rounded-2xl border border-white/[0.06] flex items-center justify-between text-xs">
            <div className="truncate pr-2">
              <span className="font-bold text-white block truncate">{order.product.title}</span>
              <span className="text-[11px] text-slate-400">Order ID: {order.id}</span>
            </div>
            <span className="text-base font-black text-fuchsia-400 shrink-0">₹{order.amount}</span>
          </div>

          {/* QR Code Container */}
          <div className="my-6 p-5 rounded-2xl bg-white flex flex-col items-center justify-center text-center shadow-inner">
            <img
              src={paymentInfo.qrCodeUrl || '/uploads/public/default_qr.svg'}
              alt="Scan UPI QR Code"
              className="w-56 h-56 object-contain"
            />
            <span className="mt-2 text-[10px] font-bold text-slate-600 tracking-wider uppercase">
              BHIM UPI · GPay · PhonePe · Paytm
            </span>
          </div>

          {/* UPI ID Copy Field */}
          <div className="p-3 bg-white/[0.03] rounded-2xl border border-white/[0.08] flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">UPI ID</span>
              <span className="text-xs font-mono font-bold text-white truncate block">
                {paymentInfo.upiId}
              </span>
            </div>
            <button
              onClick={handleCopyUpi}
              className="px-3 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] text-xs font-bold text-fuchsia-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          {/* Instructions */}
          <div className="my-6 text-xs text-slate-300 space-y-2 bg-white/[0.02] p-4 rounded-2xl border border-white/[0.06]">
            <p className="font-bold text-white flex items-center gap-1.5">
              <span>Step-by-Step Payment Instructions:</span>
            </p>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px] leading-relaxed">
              <li>Open any UPI App (Google Pay, PhonePe, Paytm).</li>
              <li>Scan the QR Code above or enter UPI ID manually.</li>
              <li>Pay the exact amount: <strong className="text-white">₹{order.amount}</strong></li>
              <li>Take a screenshot of the successful transaction.</li>
              <li>Upload the screenshot below to verify and get instant course access.</li>
            </ol>
          </div>

          {/* Screenshot Upload Form */}
          <form onSubmit={handleSubmitPayment} className="space-y-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              accept="image/jpeg,image/png,image/webp,image/jpg"
              className="hidden"
            />

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Screenshot Upload / Preview Area */}
            {previewUrl ? (
              <div className="border border-fuchsia-500/40 rounded-2xl p-5 bg-[#171226] text-center space-y-3">
                <div className="flex justify-center">
                  <img
                    src={previewUrl}
                    alt="Payment Screenshot Preview"
                    className="max-h-56 rounded-xl object-contain shadow-lg border border-white/[0.1]"
                  />
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate max-w-xs mx-auto">
                    {selectedFile?.name}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {selectedFile ? (selectedFile.size / 1024 / 1024).toFixed(2) : '0'} MB · Ready to submit
                  </p>
                </div>

                <div className="flex items-center justify-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-bold text-slate-200 transition-colors cursor-pointer"
                  >
                    Upload Another Screenshot
                  </button>
                  <button
                    type="button"
                    onClick={handleRemoveScreenshot}
                    className="px-3.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Remove Screenshot
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/[0.15] hover:border-fuchsia-500/50 rounded-2xl p-6 text-center transition-all bg-white/[0.02] hover:bg-white/[0.04] cursor-pointer"
              >
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 rounded-full bg-fuchsia-500/15 text-fuchsia-400 flex items-center justify-center mb-3">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-white">Upload Payment Screenshot *</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Click to browse (JPG, JPEG, PNG, WEBP up to 10MB)
                  </p>
                </div>
              </div>
            )}

            {/* Submit Verification Button */}
            <button
              type="submit"
              disabled={isUploading || !selectedFile}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 disabled:opacity-50 text-white font-extrabold text-sm shadow-xl shadow-violet-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              {isUploading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Uploading Screenshot...</span>
                </>
              ) : (
                <>
                  <span>Submit Payment Verification</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Need help footer */}
          <div className="mt-6 text-center text-xs text-slate-400">
            <span>Need help with payment? </span>
            <a
              href="https://wa.me/917976028995"
              target="_blank"
              rel="noopener noreferrer"
              className="text-fuchsia-400 hover:underline font-bold"
            >
              Chat on WhatsApp (+91 7976028995)
            </a>
          </div>
        </div>
      </main>
    </div>
  );
};
