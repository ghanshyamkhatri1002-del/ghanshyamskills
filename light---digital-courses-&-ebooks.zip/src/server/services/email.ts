import { EmailLog } from '../../types.ts';

interface SendEmailParams {
  orderId: string;
  customerName: string;
  customerEmail: string;
  productTitle: string;
  type: 'APPROVED' | 'REJECTED' | 'PAYMENT_SUBMITTED';
  productType?: 'course' | 'ebook';
  courseUrl?: string;
  secureAccessLink?: string;
  rejectionReason?: string;
  creatorName?: string;
}

export function formatEmailContent(params: SendEmailParams): { subject: string; body: string } {
  const creator = params.creatorName || 'GHANSHYAM SKILLS';

  if (params.type === 'APPROVED') {
    if (params.productType === 'course' && params.courseUrl) {
      return {
        subject: `Order Confirmed: Access to ${params.productTitle}`,
        body: `Hello ${params.customerName},

Great news! Your payment for "${params.productTitle}" has been verified successfully.

Your course is now available.

OPEN COURSE:
${params.courseUrl}

Thank you for purchasing from ${creator}!`,
      };
    }

    const accessLink = params.secureAccessLink || params.courseUrl || '';
    return {
      subject: `Order Confirmed: Access to ${params.productTitle}`,
      body: `Hello ${params.customerName},

Great news! Your payment for "${params.productTitle}" has been verified successfully.

Your digital access is now active.

Download your ebook:
${accessLink}

Warm regards,
${creator}`,
    };
  } else if (params.type === 'REJECTED') {
    return {
      subject: `Payment Verification Update for Order #${params.orderId}`,
      body: `Hello ${params.customerName},

We encountered an issue verifying your payment proof for "${params.productTitle}".

Reason:
${params.rejectionReason || 'The uploaded screenshot could not be matched with our bank records.'}

Please review your payment or resubmit a clear screenshot showing the transaction ID / UTR number.

Best regards,
${creator} Support`,
    };
  } else {
    return {
      subject: `Payment Received: Verification in Progress (${params.productTitle})`,
      body: `Hello ${params.customerName},

We have received your payment proof for "${params.productTitle}".

Our team is currently verifying the transaction. As soon as the verification is approved, you will receive an instant notification with your direct access.

Order ID: ${params.orderId}

Warm regards,
${creator}`,
    };
  }
}

export async function sendEmailNotification(params: SendEmailParams): Promise<EmailLog> {
  const { subject, body } = formatEmailContent(params);
  const smtpHost = process.env.SMTP_HOST;
  const smtpPort = process.env.SMTP_PORT;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASSWORD;

  let status: 'SENT' | 'FAILED' | 'MOCK_SENT' = 'MOCK_SENT';

  if (smtpHost && smtpUser && smtpPass) {
    console.log(`[SMTP EMAIL] Dispatched to ${params.customerEmail} via ${smtpHost}`);
    status = 'SENT';
  } else {
    console.log(`[EMAIL MOCK] To: ${params.customerEmail} | Subject: ${subject}\n${body}`);
    status = 'MOCK_SENT';
  }

  const log: EmailLog = {
    id: 'em_' + Math.random().toString(36).substring(2, 10),
    orderId: params.orderId,
    recipient: params.customerEmail,
    subject,
    body,
    status,
    sentAt: new Date().toISOString(),
  };

  return log;
}
