import { WhatsAppLog } from '../../types.ts';

interface SendWhatsAppParams {
  orderId: string;
  customerName: string;
  whatsappNumber: string;
  productTitle: string;
  type: 'APPROVED' | 'REJECTED';
  productType?: 'course' | 'ebook';
  courseUrl?: string;
  secureAccessLink?: string;
  rejectionReason?: string;
  creatorName?: string;
}

export function formatWhatsAppMessage(params: SendWhatsAppParams): string {
  const creator = params.creatorName || 'GHANSHYAM SKILLS';

  if (params.type === 'APPROVED') {
    const courseUrl = params.courseUrl || params.secureAccessLink || '';
    return `Hi ${params.customerName} 👋

Your payment for "${params.productTitle}" has been successfully verified! ✅

Your course access is now unlocked.

🎓 Access Your Course Here:
${courseUrl}

Thank you for learning with ${creator}! Build your future ❤️`;
  } else {
    return `Hi ${params.customerName},

We could not verify your payment for "${params.productTitle}". ⚠️

Reason:
${params.rejectionReason || 'Payment screenshot could not be verified. Please submit a valid payment screenshot.'}

Please contact us or resubmit your payment screenshot to activate your access.

— Team ${creator}`;
  }
}

export async function sendWhatsAppNotification(params: SendWhatsAppParams): Promise<WhatsAppLog> {
  const message = formatWhatsAppMessage(params);
  // Clean phone number: remove non-digits
  const cleanNumber = params.whatsappNumber.replace(/[^0-9]/g, '');
  const encodedText = encodeURIComponent(message);
  const whatsappWebUrl = `https://wa.me/${cleanNumber}?text=${encodedText}`;

  const apiUrl = process.env.WHATSAPP_API_URL;
  const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;

  let status: 'SENT' | 'FAILED' | 'MOCK_SENT' = 'MOCK_SENT';

  if (apiUrl && accessToken && phoneNumberId) {
    try {
      const response = await fetch(`${apiUrl}/${phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: cleanNumber,
          type: 'text',
          text: { body: message },
        }),
      });

      if (response.ok) {
        status = 'SENT';
      } else {
        const errText = await response.text();
        console.error('WhatsApp API returned error:', errText);
        status = 'FAILED';
      }
    } catch (err) {
      console.error('WhatsApp API request error:', err);
      status = 'FAILED';
    }
  } else {
    console.log(`[WHATSAPP MOCK] Sent to ${cleanNumber}: \n${message}\n(Direct click: ${whatsappWebUrl})`);
    status = 'MOCK_SENT';
  }

  const log: WhatsAppLog = {
    id: 'wa_' + Math.random().toString(36).substring(2, 10),
    orderId: params.orderId,
    recipient: params.whatsappNumber,
    message,
    status,
    sentAt: new Date().toISOString(),
    whatsappWebUrl,
  };

  return log;
}
