import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  Product,
  Customer,
  Order,
  PaymentSubmission,
  ProductAccess,
  SiteSettings,
  AdminUser,
  WhatsAppLog,
  EmailLog,
} from '../types.ts';
import { sendWhatsAppNotification } from './services/whatsapp.ts';
import { sendEmailNotification } from './services/email.ts';

interface DatabaseSchema {
  admin: {
    id: string;
    email: string;
    passwordHash: string;
    salt: string;
    name: string;
  };
  settings: SiteSettings;
  products: Product[];
  customers: Customer[];
  orders: Order[];
  paymentSubmissions: PaymentSubmission[];
  productAccesses: ProductAccess[];
  whatsappLogs: WhatsAppLog[];
  emailLogs: EmailLog[];
  adminSessions: { token: string; adminId: string; expiresAt: string }[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
export const PUBLIC_UPLOADS_DIR = path.join(DATA_DIR, 'uploads', 'public');
export const PRIVATE_UPLOADS_DIR = path.join(DATA_DIR, 'uploads', 'private');

// Explicit dedicated storage directories
export const PUBLIC_PROFILE_DIR = path.join(PUBLIC_UPLOADS_DIR, 'profile');
export const PUBLIC_THUMBNAILS_DIR = path.join(PUBLIC_UPLOADS_DIR, 'thumbnails');
export const PRIVATE_EBOOKS_DIR = path.join(PRIVATE_UPLOADS_DIR, 'ebooks');
export const PRIVATE_COURSE_CONTENT_DIR = path.join(PRIVATE_UPLOADS_DIR, 'course-content');
export const PRIVATE_PAYMENT_SCREENSHOTS_DIR = path.join(PRIVATE_UPLOADS_DIR, 'payment-screenshots');
export const PRIVATE_QR_DIR = path.join(PRIVATE_UPLOADS_DIR, 'qr');

// Ensure directories exist
for (const dir of [
  DATA_DIR,
  PUBLIC_UPLOADS_DIR,
  PRIVATE_UPLOADS_DIR,
  PUBLIC_PROFILE_DIR,
  PUBLIC_THUMBNAILS_DIR,
  PRIVATE_EBOOKS_DIR,
  PRIVATE_COURSE_CONTENT_DIR,
  PRIVATE_PAYMENT_SCREENSHOTS_DIR,
  PRIVATE_QR_DIR,
]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Password hashing utilities using crypto
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

export function generateSecureToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

// Generate minimal valid PDF for sample ebooks
function ensureSampleEbookFiles() {
  const sampleEbookPath = path.join(PRIVATE_UPLOADS_DIR, 'sample_freelancer_playbook.pdf');
  if (!fs.existsSync(sampleEbookPath)) {
    const minimalPdf = `%PDF-1.4
1 0 obj
<< /Title (GHANSHYAM SKILLS Resource Guide)
   /Author (GHANSHYAM SKILLS)
>>
endobj
2 0 obj
<< /Type /Catalog
   /Pages 3 0 R
>>
endobj
3 0 obj
<< /Type /Pages
   /Kids [4 0 R]
   /Count 1
>>
endobj
4 0 obj
<< /Type /Page
   /Parent 3 0 R
   /MediaBox [0 0 612 792]
   /Contents 5 0 R
   /Resources << /Font << /F1 6 0 R >> >>
>>
endobj
5 0 obj
<< /Length 195 >>
stream
BT
/F1 24 Tf
50 720 Td
(GHANSHYAM SKILLS Resource Guide) Tj
/F1 14 Tf
0 -40 Td
(Thank you for your purchase! This is your verified digital copy.) Tj
0 -30 Td
(Master value-based pricing, high-ticket proposals and client close rates.) Tj
ET
endstream
endobj
6 0 obj
<< /Type /Font
   /Subtype /Type1
   /BaseFont /Helvetica-Bold
>>
endobj
xref
0 7
0000000000 65535 f 
0000000009 00000 n 
0000000085 00000 n 
0000000135 00000 n 
0000000192 00000 n 
0000000305 00000 n 
0000000553 00000 n 
trailer
<< /Size 7
   /Root 2 0 R
   /Info 1 0 R
>>
startxref
630
%%EOF`;
    fs.writeFileSync(sampleEbookPath, minimalPdf, 'utf-8');
  }
}

// Create clean QR code SVG asset if not already saved
function getInitialQrSvg(): string {
  // A clean, high-contrast QR visual representation with UPI branding
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="300" height="300">
    <rect width="300" height="300" fill="#ffffff" rx="16"/>
    <rect x="25" y="25" width="70" height="70" fill="#0f172a" rx="8"/>
    <rect x="35" y="35" width="50" height="50" fill="#ffffff" rx="4"/>
    <rect x="45" y="45" width="30" height="30" fill="#0f172a" rx="2"/>

    <rect x="205" y="25" width="70" height="70" fill="#0f172a" rx="8"/>
    <rect x="215" y="35" width="50" height="50" fill="#ffffff" rx="4"/>
    <rect x="225" y="45" width="30" height="30" fill="#0f172a" rx="2"/>

    <rect x="25" y="205" width="70" height="70" fill="#0f172a" rx="8"/>
    <rect x="35" y="215" width="50" height="50" fill="#ffffff" rx="4"/>
    <rect x="45" y="225" width="30" height="30" fill="#0f172a" rx="2"/>

    <!-- Grid Modules -->
    <rect x="110" y="25" width="16" height="16" fill="#0f172a"/>
    <rect x="140" y="25" width="16" height="16" fill="#0f172a"/>
    <rect x="170" y="40" width="16" height="16" fill="#0f172a"/>
    <rect x="110" y="55" width="16" height="16" fill="#0f172a"/>
    <rect x="140" y="70" width="16" height="16" fill="#0f172a"/>
    <rect x="170" y="85" width="16" height="16" fill="#0f172a"/>

    <rect x="25" y="110" width="16" height="16" fill="#0f172a"/>
    <rect x="55" y="125" width="16" height="16" fill="#0f172a"/>
    <rect x="85" y="140" width="16" height="16" fill="#0f172a"/>
    <rect x="25" y="155" width="16" height="16" fill="#0f172a"/>
    <rect x="70" y="170" width="16" height="16" fill="#0f172a"/>

    <rect x="115" y="115" width="70" height="70" fill="#0f172a" rx="12"/>
    <circle cx="150" cy="150" r="22" fill="#ffffff"/>
    <path d="M142 142 L158 142 L150 158 Z" fill="#0f172a"/>

    <rect x="205" y="110" width="16" height="16" fill="#0f172a"/>
    <rect x="235" y="125" width="16" height="16" fill="#0f172a"/>
    <rect x="265" y="140" width="16" height="16" fill="#0f172a"/>
    <rect x="220" y="170" width="16" height="16" fill="#0f172a"/>

    <rect x="110" y="205" width="16" height="16" fill="#0f172a"/>
    <rect x="140" y="220" width="16" height="16" fill="#0f172a"/>
    <rect x="170" y="235" width="16" height="16" fill="#0f172a"/>
    <rect x="110" y="250" width="16" height="16" fill="#0f172a"/>
    <rect x="155" y="265" width="16" height="16" fill="#0f172a"/>

    <rect x="205" y="205" width="16" height="16" fill="#0f172a"/>
    <rect x="235" y="220" width="16" height="16" fill="#0f172a"/>
    <rect x="265" y="250" width="16" height="16" fill="#0f172a"/>
    <rect x="220" y="265" width="16" height="16" fill="#0f172a"/>
  </svg>`;
}

function ensureDefaultQrImage() {
  const qrPath = path.join(PUBLIC_UPLOADS_DIR, 'default_qr.svg');
  if (!fs.existsSync(qrPath)) {
    fs.writeFileSync(qrPath, getInitialQrSvg(), 'utf-8');
  }
}

// Initial seed
function getInitialData(): DatabaseSchema {
  const defaultSalt = crypto.randomBytes(16).toString('hex');
  const defaultPassword = process.env.ADMIN_PASSWORD || 'admin123456';
  const defaultEmail = process.env.ADMIN_EMAIL || 'admin@ghanshyamskills.com';
  const passwordHash = hashPassword(defaultPassword, defaultSalt);

  ensureSampleEbookFiles();
  ensureDefaultQrImage();

  const customer1: Customer = {
    id: 'cust_01',
    name: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    whatsappNumber: '+91 98765 12345',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  };

  const customer2: Customer = {
    id: 'cust_02',
    name: 'Priya Patel',
    email: 'priya.patel@example.com',
    whatsappNumber: '+91 98123 45678',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
  };

  const customer3: Customer = {
    id: 'cust_03',
    name: 'Asha Rao',
    email: 'asha.rao@example.com',
    whatsappNumber: '+91 98765 22334',
    createdAt: new Date(Date.now() - 3600000 * 1).toISOString(),
  };

  const products: Product[] = [
    {
      id: 'prod_whatsapp_auto',
      type: 'course',
      title: 'WhatsApp Automation Masterclass',
      slug: 'whatsapp-automation-masterclass',
      thumbnailUrl: 'https://images.unsplash.com/photo-1611746872915-64382b5c76da?auto=format&fit=crop&w=1280&q=80',
      shortDescription: 'Learn how to automate customer chats, broadcasts, lead capture and orders on WhatsApp effortlessly.',
      description: `Comprehensive step-by-step masterclass on automating WhatsApp for business, creators, and freelancers.

### What you will learn:
- Official WhatsApp Cloud API setup without monthly recurring subscription fees
- Automated lead capture, interactive buttons, and instant FAQ replies
- Order confirmation, payment receipts, and automated digital delivery
- Broadcast campaigns with high delivery & open rates without getting banned
- Integration with Google Sheets, Webhooks, Razorpay & UPI alerts

Direct course access provided immediately upon payment verification.`,
      price: 21,
      originalPrice: 499,
      discountPercentage: 75,
      badgeText: '75% OFF',
      showBadge: true,
      duration: '3.5 Hours',
      lessonCount: '14 Lessons',
      contentUrl: 'https://ghanshyamskills.com/whatsapp-automation',
      status: 'active',
      lessons: [
        {
          id: 'les_wa_1',
          title: '01. WhatsApp API Architecture & Free Account Setup',
          videoUrl: 'https://ghanshyamskills.com/whatsapp-automation',
          description: 'Getting Meta developer credentials, phone number verification and test tokens.',
          duration: '22 mins',
        },
        {
          id: 'les_wa_2',
          title: '02. Building Interactive Chatbots & Webhooks',
          videoUrl: 'https://ghanshyamskills.com/whatsapp-automation',
          description: 'Deploying auto-responders, quick reply buttons, and lead routing.',
          duration: '35 mins',
        },
      ],
      createdAt: new Date(Date.now() - 86400000 * 0.5).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 0.5).toISOString(),
    },
    {
      id: 'prod_fullstack',
      type: 'course',
      title: 'Full Stack Web & AI Development Masterclass',
      slug: 'full-stack-web-ai-development',
      thumbnailUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1280&q=80',
      shortDescription: 'Build production-ready full stack web applications with React, Next.js, Node.js & modern AI integration.',
      description: `Comprehensive masterclass on modern full stack engineering. From React & Next.js architectures to backend APIs, database design, authentication, and integrating AI models.

### What you will learn:
- Next.js 15 App Router, Server Actions & Streaming UI
- TypeScript from beginner patterns to production generics
- Node.js, Express & scalable PostgreSQL database modeling
- Authentication, payment gateways & webhook security
- Building real-world AI applications with Gemini & OpenAI APIs
- Production deployment, Docker & CI/CD workflows

Direct course access provided immediately upon payment verification.`,
      price: 999,
      originalPrice: 4999,
      discountPercentage: 80,
      badgeText: '80% OFF',
      showBadge: true,
      duration: '18.5 Hours',
      lessonCount: '42 Lessons',
      contentUrl: 'https://ghanshyamskills.com/fullstack-course',
      status: 'active',
      lessons: [
        {
          id: 'les_fs_1',
          title: '01. Modern Full Stack Architecture & Roadmap',
          videoUrl: 'https://ghanshyamskills.com/fullstack-course',
          description: 'Understanding client vs server components, state management and data flows.',
          duration: '30 mins',
        },
        {
          id: 'les_fs_2',
          title: '02. Database Design & API Security',
          videoUrl: 'https://ghanshyamskills.com/fullstack-course',
          description: 'Structuring schemas, migrations, and handling secure bearer tokens.',
          duration: '45 mins',
        },
      ],
      createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    },
    {
      id: 'prod_flutter',
      type: 'course',
      title: 'Flutter & Dart Mobile App Development Masterclass',
      slug: 'flutter-mobile-app-development',
      thumbnailUrl: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=1280&q=80',
      shortDescription: 'Master Flutter 3 & Dart from scratch. Build and publish high-performance iOS and Android applications.',
      description: `Complete Flutter masterclass. Build production-grade cross-platform apps with beautiful modern UIs, responsive widgets, and clean architecture.

### What you will learn:
- Dart language fundamentals & advanced object-oriented programming
- State management with Riverpod and Bloc
- Native device integrations (Camera, Storage, GPS, Biometrics)
- Clean Architecture, REST APIs, and Offline-first caching
- Automated publishing to Google Play Store & Apple App Store

Course link provided directly after payment verification.`,
      price: 499,
      originalPrice: 2999,
      discountPercentage: 83,
      contentUrl: 'https://ghanshyamskills.com/flutter-course',
      status: 'active',
      lessons: [
        {
          id: 'les_fl_1',
          title: '01. Flutter 3 Environment Setup & Dart Core',
          videoUrl: 'https://ghanshyamskills.com/flutter-course',
          description: 'Getting started with Flutter tooling, DevTools, and modern syntax.',
          duration: '35 mins',
        },
        {
          id: 'les_fl_2',
          title: '02. Widget Tree, Layouts & Theming',
          videoUrl: 'https://ghanshyamskills.com/flutter-course',
          description: 'Building responsive layouts that look native on all devices.',
          duration: '42 mins',
        },
      ],
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
    {
      id: 'prod_uiux',
      type: 'course',
      title: 'Modern UI/UX Design System & Figma Mastery',
      slug: 'modern-ui-ux-design-systems',
      thumbnailUrl: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=1280&q=80',
      shortDescription: 'Learn professional Figma workflows, design tokens, micro-interactions, and design systems for web apps.',
      description: `Comprehensive video training on architecting production-grade UI design systems. From design tokens to atomic design patterns.

### Course Outline:
- Design Tokens: colors, typography scales, spacing grids
- Building robust component sets in Figma & Tailwind
- Handling dark mode, responsive states, and accessibility contrast
- Maintaining documentation that developers love

### Access:
- Immediate on-demand video access
- Component library starter files
- Lifetime updates`,
      price: 499,
      originalPrice: 2499,
      discountPercentage: 80,
      contentUrl: 'https://ghanshyamskills.com/ui-ux-masterclass',
      status: 'active',
      lessons: [
        {
          id: 'les_3_1',
          title: '01. Token Architecture & Variables',
          videoUrl: 'https://ghanshyamskills.com/ui-ux-masterclass',
          description: 'Structuring color palettes, typography scales and spatial rules.',
          duration: '32 mins',
        },
        {
          id: 'les_3_2',
          title: '02. Accessible Interactive States',
          videoUrl: 'https://ghanshyamskills.com/ui-ux-masterclass',
          description: 'Focus states, active touches, and dark mode transitions.',
          duration: '28 mins',
        },
      ],
      createdAt: new Date(Date.now() - 86400000 * 7).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 7).toISOString(),
    },
  ];

  const order1: Order = {
    id: 'ORD-719283',
    customerId: customer1.id,
    customer: customer1,
    productId: products[0].id,
    product: products[0],
    amount: products[0].price,
    status: 'PAYMENT_SUBMITTED',
    paymentSubmission: {
      id: 'sub_01',
      orderId: 'ORD-719283',
      screenshotUrl: 'https://images.unsplash.com/photo-1556742049-0a67e557224d?auto=format&fit=crop&w=800&q=80',
      submittedAt: new Date(Date.now() - 3600000 * 1.5).toISOString(),
    },
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 1.5).toISOString(),
  };

  const sampleApprovedToken = 'demo-access-token-ghanshyam-8829';
  const order2: Order = {
    id: 'ORD-602914',
    customerId: customer2.id,
    customer: customer2,
    productId: products[1].id,
    product: products[1],
    amount: products[1].price,
    status: 'APPROVED',
    paymentSubmission: {
      id: 'sub_02',
      orderId: 'ORD-602914',
      screenshotUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80',
      submittedAt: new Date(Date.now() - 3600000 * 24).toISOString(),
      reviewedAt: new Date(Date.now() - 3600000 * 23).toISOString(),
    },
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 23).toISOString(),
  };

  const productAccess2: ProductAccess = {
    id: 'acc_02',
    customerId: customer2.id,
    productId: products[1].id,
    orderId: order2.id,
    accessToken: sampleApprovedToken,
    status: 'ACTIVE',
    createdAt: new Date(Date.now() - 3600000 * 23).toISOString(),
  };

  const order3: Order = {
    id: 'ORD-918274',
    customerId: customer3.id,
    customer: customer3,
    productId: products[0].id,
    product: products[0],
    amount: products[0].price,
    status: 'PAYMENT_SUBMITTED',
    paymentSubmission: {
      id: 'sub_03',
      orderId: 'ORD-918274',
      screenshotUrl: 'https://images.unsplash.com/photo-1556742049-0a67e557224d?auto=format&fit=crop&w=800&q=80',
      submittedAt: new Date(Date.now() - 3600000 * 0.5).toISOString(),
    },
    createdAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 0.5).toISOString(),
  };

  return {
    admin: {
      id: 'admin_root',
      email: defaultEmail,
      passwordHash,
      salt: defaultSalt,
      name: 'Ghanshyam Admin',
    },
    settings: {
      creatorName: 'GHANSHYAM SKILLS',
      subtitle: 'Learn Skills. Build Your Future.',
      creatorBio: 'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.',
      profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&h=600&q=80',
      heroBackgroundImage: '',
      heroHeading: 'GHANSHYAM SKILLS',
      heroSubtitle: 'Learn Skills. Build Your Future.',
      heroDescription: 'Master practical digital skills with step-by-step courses, real-world projects and beginner-friendly guidance.',
      heroCtaText: 'Chat on WhatsApp',
      whatsappNumber: '+91 7976028995',
      whatsappButtonText: '💬 Chat on WhatsApp',
      whatsappButtonIcon: 'message-circle',
      whatsappButtonVisible: true,
      supportWhatsappNumber: '+91 7976028995',
      upiId: '7976028995@upi',
      paymentInstructions: '1. Open any UPI app such as Google Pay, PhonePe or Paytm.\n2. Scan the QR code or enter the UPI ID manually.\n3. Pay the exact course amount.\n4. Take a screenshot of the successful payment.\n5. Upload the payment screenshot below.',
      paymentQrCode: '/uploads/public/default_qr.svg',
      bgTheme: 'dark-violet',
      accentColor: 'violet',
      primaryColor: '#8b5cf6',
      secondaryColor: '#d946ef',
      buttonColor: '#10b981',
      footerText: '© 2026 GHANSHYAM SKILLS. Learn Skills. Build Your Future.',
      whatsappEnabled: true,
      whatsappApiUrl: process.env.WHATSAPP_API_URL || '',
      whatsappTokenConfigured: Boolean(process.env.WHATSAPP_ACCESS_TOKEN),
      emailEnabled: true,
      smtpConfigured: Boolean(process.env.SMTP_HOST),
    },
    products,
    customers: [customer1, customer2, customer3],
    orders: [order3, order1, order2],
    paymentSubmissions: [order3.paymentSubmission!, order1.paymentSubmission!, order2.paymentSubmission!],
    productAccesses: [productAccess2],
    whatsappLogs: [],
    emailLogs: [],
    adminSessions: [],
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed: DatabaseSchema = JSON.parse(raw);
        const initial = getInitialData();

        // Migrate to GHANSHYAM SKILLS branding if old store settings exist
        if (!parsed.settings || parsed.settings.creatorName === 'Light' || !parsed.settings.subtitle) {
          parsed.settings = initial.settings;
          parsed.products = initial.products;
          parsed.orders = initial.orders;
          this.saveDirect(parsed);
          return parsed;
        }

        // Ensure all new settings fields are present
        parsed.settings = { ...initial.settings, ...parsed.settings };

        // Filter out any lingering non-course products to guarantee COURSES ONLY
        const courseOnly = parsed.products.filter((p) => p.type === 'course');
        if (courseOnly.length !== parsed.products.length) {
          parsed.products = courseOnly;
          this.saveDirect(parsed);
        }

        return parsed;
      }
    } catch (err) {
      console.error('Failed to load database.json, initializing fresh data:', err);
    }
    const initial = getInitialData();
    this.saveDirect(initial);
    return initial;
  }

  private saveDirect(data: DatabaseSchema): void {
    const tempFile = DB_FILE + '.tmp';
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  }

  public save(): void {
    this.saveDirect(this.data);
  }

  // Admin authentication
  public verifyAdmin(email: string, pass: string): AdminUser | null {
    const inputEmail = email.trim().toLowerCase();
    const currentEmail = this.data.admin.email.trim().toLowerCase();
    // Allow either the configured admin email or admin@ghanshyamskills.com
    const isAllowedEmail =
      inputEmail === currentEmail ||
      inputEmail === 'admin@ghanshyamskills.com';

    if (!isAllowedEmail) {
      return null;
    }
    const calculatedHash = hashPassword(pass, this.data.admin.salt);
    if (calculatedHash === this.data.admin.passwordHash) {
      return {
        id: this.data.admin.id,
        email: this.data.admin.email,
        name: this.data.admin.name,
      };
    }
    return null;
  }

  public createAdminSession(adminId: string): string {
    const token = generateSecureToken(32);
    const expiresAt = new Date(Date.now() + 7 * 86400000).toISOString(); // 7 days
    this.data.adminSessions.push({ token, adminId, expiresAt });
    this.save();
    return token;
  }

  public verifyAdminSession(token: string): AdminUser | null {
    if (!token) return null;
    const session = this.data.adminSessions.find(
      (s) => s.token === token && new Date(s.expiresAt) > new Date()
    );
    if (!session) return null;
    return {
      id: this.data.admin.id,
      email: this.data.admin.email,
      name: this.data.admin.name,
    };
  }

  public deleteAdminSession(token: string): void {
    this.data.adminSessions = this.data.adminSessions.filter((s) => s.token !== token);
    this.save();
  }

  // Settings
  public getSettings(): SiteSettings {
    return { ...this.data.settings };
  }

  public updateSettings(partial: Partial<SiteSettings>): SiteSettings {
    this.data.settings = { ...this.data.settings, ...partial };
    this.save();
    return this.data.settings;
  }

  // Products
  public getProducts(onlyActive = false): Product[] {
    if (onlyActive) {
      return this.data.products.filter((p) => p.status === 'active');
    }
    return [...this.data.products];
  }

  public getProductBySlug(slug: string): Product | null {
    return this.data.products.find((p) => p.slug === slug) || null;
  }

  public getProductById(id: string): Product | null {
    return this.data.products.find((p) => p.id === id) || null;
  }

  public createProduct(data: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product {
    const id = 'prod_' + Math.random().toString(36).substring(2, 9);
    const now = new Date().toISOString();
    // Compute discount if originalPrice provided
    let discountPercentage = data.discountPercentage;
    if (data.originalPrice && data.originalPrice > data.price) {
      discountPercentage = Math.round(((data.originalPrice - data.price) / data.originalPrice) * 100);
    }
    const newProduct: Product = {
      ...data,
      id,
      discountPercentage,
      createdAt: now,
      updatedAt: now,
    };
    this.data.products.unshift(newProduct);
    this.save();
    return newProduct;
  }

  public updateProduct(id: string, partial: Partial<Product>): Product | null {
    const idx = this.data.products.findIndex((p) => p.id === id);
    if (idx === -1) return null;
    const existing = this.data.products[idx];
    const updatedPrice = partial.price !== undefined ? partial.price : existing.price;
    const updatedOriginal = partial.originalPrice !== undefined ? partial.originalPrice : existing.originalPrice;
    let discountPercentage = partial.discountPercentage !== undefined ? partial.discountPercentage : existing.discountPercentage;
    if (updatedOriginal && updatedOriginal > updatedPrice) {
      discountPercentage = Math.round(((updatedOriginal - updatedPrice) / updatedOriginal) * 100);
    }
    this.data.products[idx] = {
      ...existing,
      ...partial,
      price: updatedPrice,
      originalPrice: updatedOriginal,
      discountPercentage,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.data.products[idx];
  }

  public deleteProduct(id: string): boolean {
    const beforeLen = this.data.products.length;
    this.data.products = this.data.products.filter((p) => p.id !== id);
    const deleted = this.data.products.length < beforeLen;
    if (deleted) this.save();
    return deleted;
  }

  // Orders
  public getOrders(): Order[] {
    return [...this.data.orders].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getOrderById(id: string): Order | null {
    return this.data.orders.find((o) => o.id === id) || null;
  }

  public createOrder(params: {
    productId: string;
    customerName: string;
    customerEmail: string;
    customerWhatsapp: string;
  }): Order {
    const product = this.getProductById(params.productId);
    if (!product) throw new Error('Product not found');

    const customerId = 'cust_' + Math.random().toString(36).substring(2, 9);
    const customer: Customer = {
      id: customerId,
      name: params.customerName.trim(),
      email: params.customerEmail.trim().toLowerCase(),
      whatsappNumber: params.customerWhatsapp.trim(),
      createdAt: new Date().toISOString(),
    };
    this.data.customers.push(customer);

    const orderId = 'ORD-' + Math.floor(100000 + Math.random() * 900000);
    const now = new Date().toISOString();
    const order: Order = {
      id: orderId,
      customerId: customer.id,
      customer,
      productId: product.id,
      product,
      amount: product.price,
      status: 'PENDING_PAYMENT',
      createdAt: now,
      updatedAt: now,
    };

    this.data.orders.unshift(order);
    this.save();
    return order;
  }

  public submitPaymentScreenshot(orderId: string, screenshotUrl: string): Order {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found');

    const subId = 'sub_' + Math.random().toString(36).substring(2, 9);
    const submission: PaymentSubmission = {
      id: subId,
      orderId,
      screenshotUrl,
      submittedAt: new Date().toISOString(),
    };

    order.paymentSubmission = submission;
    order.status = 'PAYMENT_SUBMITTED';
    order.updatedAt = new Date().toISOString();

    // Store submission in submissions table
    this.data.paymentSubmissions.push(submission);
    this.save();

    // Send email acknowledgement
    sendEmailNotification({
      orderId: order.id,
      customerName: order.customer.name,
      customerEmail: order.customer.email,
      productTitle: order.product.title,
      type: 'PAYMENT_SUBMITTED',
      creatorName: this.data.settings.creatorName,
    }).then((log) => {
      this.data.emailLogs.unshift(log);
      this.save();
    });

    return order;
  }

  public async approveOrder(orderId: string, appUrl: string): Promise<{
    order: Order;
    access: ProductAccess;
    destinationUrl: string;
    isCourse: boolean;
    courseUrl?: string;
  }> {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found');

    // Always fetch latest product to guarantee updated contentUrl from admin edits
    const latestProduct = this.getProductById(order.productId);
    if (latestProduct) {
      order.product = latestProduct;
    }

    order.status = 'APPROVED';
    order.updatedAt = new Date().toISOString();
    if (order.paymentSubmission) {
      order.paymentSubmission.reviewedAt = new Date().toISOString();
      order.paymentSubmission.rejectionReason = undefined;
    }

    // Check if access already exists for this order
    let access = this.data.productAccesses.find((a) => a.orderId === orderId);
    if (!access) {
      const accessToken = generateSecureToken(32);
      access = {
        id: 'acc_' + Math.random().toString(36).substring(2, 9),
        customerId: order.customerId,
        productId: order.productId,
        orderId: order.id,
        accessToken,
        status: 'ACTIVE',
        createdAt: new Date().toISOString(),
      };
      this.data.productAccesses.push(access);
    }
    order.productAccess = access;

    const isCourse = order.product.type === 'course';
    const courseUrl = order.product.contentUrl;
    // For Course products, the customer destination is the EXACT admin-entered course link!
    const destinationUrl =
      isCourse && courseUrl ? courseUrl : `${appUrl}/access/${access.accessToken}`;

    // Send WhatsApp notification with the exact course link
    const waLog = await sendWhatsAppNotification({
      orderId: order.id,
      customerName: order.customer.name,
      whatsappNumber: order.customer.whatsappNumber,
      productTitle: order.product.title,
      type: 'APPROVED',
      productType: order.product.type,
      courseUrl,
      secureAccessLink: destinationUrl,
      creatorName: this.data.settings.creatorName,
    });
    this.data.whatsappLogs.unshift(waLog);

    // Send Email notification with the exact course link
    const emailLog = await sendEmailNotification({
      orderId: order.id,
      customerName: order.customer.name,
      customerEmail: order.customer.email,
      productTitle: order.product.title,
      type: 'APPROVED',
      productType: order.product.type,
      courseUrl,
      secureAccessLink: destinationUrl,
      creatorName: this.data.settings.creatorName,
    });
    this.data.emailLogs.unshift(emailLog);

    this.save();
    return { order, access, destinationUrl, isCourse, courseUrl };
  }

  public async rejectOrder(orderId: string, reason?: string): Promise<Order> {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found');

    order.status = 'REJECTED';
    order.updatedAt = new Date().toISOString();
    if (order.paymentSubmission) {
      order.paymentSubmission.reviewedAt = new Date().toISOString();
      order.paymentSubmission.rejectionReason = reason || 'Payment proof could not be verified.';
    }

    // Revoke any access if it existed
    const access = this.data.productAccesses.find((a) => a.orderId === orderId);
    if (access) {
      access.status = 'REVOKED';
    }

    this.save();

    // Send WhatsApp rejection notification
    const waLog = await sendWhatsAppNotification({
      orderId: order.id,
      customerName: order.customer.name,
      whatsappNumber: order.customer.whatsappNumber,
      productTitle: order.product.title,
      type: 'REJECTED',
      rejectionReason: reason,
      creatorName: this.data.settings.creatorName,
    });
    this.data.whatsappLogs.unshift(waLog);

    // Send Email rejection notification
    const emailLog = await sendEmailNotification({
      orderId: order.id,
      customerName: order.customer.name,
      customerEmail: order.customer.email,
      productTitle: order.product.title,
      type: 'REJECTED',
      rejectionReason: reason,
      creatorName: this.data.settings.creatorName,
    });
    this.data.emailLogs.unshift(emailLog);

    this.save();
    return order;
  }

  // Customer Product Access
  public getProductAccessByToken(token: string): {
    access: ProductAccess;
    product: Product;
    customer: Customer;
    order: Order;
  } | null {
    if (!token) return null;
    const access = this.data.productAccesses.find(
      (a) => a.accessToken === token && a.status === 'ACTIVE'
    );
    if (!access) return null;

    const order = this.data.orders.find((o) => o.id === access.orderId);
    if (!order || order.status !== 'APPROVED') return null;

    const product = this.data.products.find((p) => p.id === access.productId);
    const customer = this.data.customers.find((c) => c.id === access.customerId);
    if (!product || !customer) return null;

    return { access, product, customer, order };
  }

  // Notification logs
  public getWhatsAppLogs(): WhatsAppLog[] {
    return [...this.data.whatsappLogs];
  }

  public getEmailLogs(): EmailLog[] {
    return [...this.data.emailLogs];
  }
}

export const db = new Database();
