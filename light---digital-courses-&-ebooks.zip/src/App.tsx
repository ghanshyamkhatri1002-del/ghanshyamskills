import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { StorefrontPage } from './pages/StorefrontPage.tsx';
import { ProductDetailPage } from './pages/ProductDetailPage.tsx';
import { PaymentPage } from './pages/PaymentPage.tsx';
import { CustomerAccessPage } from './pages/CustomerAccessPage.tsx';
import { AdminLoginPage } from './pages/admin/AdminLoginPage.tsx';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage.tsx';
import { AdminProductsPage } from './pages/admin/AdminProductsPage.tsx';
import { AdminProductFormPage } from './pages/admin/AdminProductFormPage.tsx';
import { AdminOrdersPage } from './pages/admin/AdminOrdersPage.tsx';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage.tsx';

function Router() {
  const [currentPath, setCurrentPath] = useState<string>(() => window.location.pathname || '/');
  const { admin, isLoading } = useAuth();

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo(0, 0);
  };

  // Route matching
  const renderRoute = () => {
    // 1. Root and Storefront
    if (currentPath === '/' || currentPath === '/ghanshyam') {
      return <StorefrontPage navigate={navigate} />;
    }

    // 2. Product Detail: /product/:slug
    if (currentPath.startsWith('/product/')) {
      const slug = currentPath.replace('/product/', '').split('?')[0].split('#')[0];
      return <ProductDetailPage slug={slug} navigate={navigate} />;
    }

    // 3. Payment Page: /payment/:orderId
    if (currentPath.startsWith('/payment/')) {
      const orderId = currentPath.replace('/payment/', '').split('?')[0].split('#')[0];
      return <PaymentPage orderId={orderId} navigate={navigate} />;
    }

    // 4. Customer Access Page: /access/:token
    if (currentPath.startsWith('/access/')) {
      const token = currentPath.replace('/access/', '').split('?')[0].split('#')[0];
      return <CustomerAccessPage token={token} navigate={navigate} />;
    }

    // 5. Admin Login: /admin/login
    if (currentPath === '/admin/login') {
      if (admin) {
        return <AdminDashboardPage navigate={navigate} />;
      }
      return <AdminLoginPage navigate={navigate} />;
    }

    // 6. Protected Admin Routes
    if (currentPath.startsWith('/admin')) {
      if (isLoading) {
        return (
          <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4">
            <div className="text-center">
              <div className="w-8 h-8 border-3 border-fuchsia-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-400">Verifying session...</p>
            </div>
          </div>
        );
      }

      if (!admin) {
        return <AdminLoginPage navigate={navigate} />;
      }

      if (currentPath === '/admin' || currentPath === '/admin/') {
        return <AdminDashboardPage navigate={navigate} />;
      }

      if (currentPath === '/admin/products') {
        return <AdminProductsPage navigate={navigate} />;
      }

      if (currentPath === '/admin/products/new') {
        return <AdminProductFormPage navigate={navigate} />;
      }

      if (currentPath.startsWith('/admin/products/edit/')) {
        const productId = currentPath.replace('/admin/products/edit/', '').split('?')[0];
        return <AdminProductFormPage productId={productId} navigate={navigate} />;
      }

      if (currentPath === '/admin/orders') {
        return <AdminOrdersPage navigate={navigate} />;
      }

      if (currentPath === '/admin/settings') {
        return <AdminSettingsPage navigate={navigate} />;
      }
    }

    // Fallback: 404 or redirect
    return (
      <div className="min-h-screen bg-[#07050E] flex items-center justify-center p-4 text-white">
        <div className="max-w-md w-full bg-[#120F1F] rounded-3xl p-8 border border-white/[0.1] text-center shadow-2xl">
          <h2 className="text-xl font-bold text-white">Page Not Found</h2>
          <p className="text-xs text-slate-400 mt-2 mb-6">
            The page you requested ({currentPath}) does not exist.
          </p>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-bold hover:shadow-lg transition-all cursor-pointer"
          >
            Go to Storefront
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#07050E] text-slate-100 selection:bg-fuchsia-600 selection:text-white">
      <Navbar currentPath={currentPath} navigate={navigate} />
      <div className="flex-1">{renderRoute()}</div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}
