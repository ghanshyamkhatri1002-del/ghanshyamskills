import React, { useState, useRef } from 'react';
import {
  Video,
  Link as LinkIcon,
  FileText,
  Upload,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface ContentUploadProps {
  type: 'course' | 'ebook';
  contentUrl: string;
  fileUrl: string;
  fileName: string;
  onContentUrlChange: (url: string) => void;
  onFileUploadChange: (fileUrl: string, fileName: string) => void;
  token?: string | null;
}

export const ContentUpload: React.FC<ContentUploadProps> = ({
  type,
  contentUrl,
  fileUrl,
  fileName,
  onContentUrlChange,
  onFileUploadChange,
  token,
}) => {
  const [courseOption, setCourseOption] = useState<'link' | 'upload'>(() => {
    return fileUrl && !contentUrl ? 'upload' : 'link';
  });

  const [isUploading, setIsUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [uploadedSize, setUploadedSize] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleFileUpload = async (file: File) => {
    setErrorMessage('');
    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const endpoint =
        type === 'course' ? '/api/admin/upload/course-content' : '/api/admin/upload/ebook';

      const headers: HeadersInit = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to upload digital file');
      }

      onFileUploadChange(data.fileUrl, data.fileName || file.name);
      setUploadedSize(formatFileSize(data.size || file.size));
    } catch (err: any) {
      setErrorMessage(err.message || 'Error uploading file.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveFile = () => {
    onFileUploadChange('', '');
    setUploadedSize('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (type === 'course') {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
            Course Content Delivery <span className="text-rose-500">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3 max-w-md">
            <button
              type="button"
              onClick={() => setCourseOption('link')}
              className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                courseOption === 'link'
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <LinkIcon className="w-4 h-4 shrink-0" />
              <div>
                <span className="text-xs font-bold block">Course Link</span>
                <span className="text-[11px] opacity-80">Direct URL access</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setCourseOption('upload')}
              className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                courseOption === 'upload'
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Upload className="w-4 h-4 shrink-0" />
              <div>
                <span className="text-xs font-bold block">Upload Video</span>
                <span className="text-[11px] opacity-80">Hosted video file</span>
              </div>
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {courseOption === 'link' ? (
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Course Link <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={contentUrl}
              onChange={(e) => onContentUrlChange(e.target.value)}
              placeholder="https://example.com/my-course"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Customer receives this EXACT link upon payment approval (via OPEN COURSE and WhatsApp).
            </p>
          </div>
        ) : (
          <div>
            <input
              type="file"
              ref={fileInputRef}
              accept="video/mp4, video/webm, video/quicktime, application/zip, application/pdf"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFileUpload(e.target.files[0]);
              }}
              className="hidden"
            />

            {fileUrl ? (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0">
                    <Video className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-slate-900 block truncate">
                      {fileName || 'Course video uploaded'}
                    </span>
                    <span className="text-[11px] text-slate-600">
                      {uploadedSize ? `Size: ${uploadedSize} · ` : ''}Stored in private course storage
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold rounded-lg border border-slate-200"
                  >
                    Change Video
                  </button>
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg border border-rose-200"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer border-2 border-dashed border-slate-300 hover:border-slate-500 rounded-2xl p-6 text-center bg-slate-50/60 hover:bg-slate-50 transition-all"
              >
                {isUploading ? (
                  <div className="py-2 flex flex-col items-center justify-center">
                    <RefreshCw className="w-6 h-6 animate-spin text-slate-900 mb-2" />
                    <span className="text-xs font-bold text-slate-800">Uploading Course Video...</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center">
                    <div className="w-10 h-10 rounded-xl bg-slate-200/70 text-slate-700 flex items-center justify-center mb-2">
                      <Video className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold text-slate-900">Upload Course Video / File</span>
                    <span className="text-[11px] text-slate-600 mt-0.5">
                      MP4, WEBM, MOV, or ZIP up to 150 MB
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  // Ebook Content: PDF Upload
  return (
    <div className="space-y-3">
      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
        Ebook Digital File (PDF) <span className="text-rose-500">*</span>
      </label>

      {errorMessage && (
        <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
          <span>{errorMessage}</span>
        </div>
      )}

      <input
        type="file"
        ref={fileInputRef}
        accept="application/pdf, application/epub+zip"
        onChange={(e) => {
          if (e.target.files?.[0]) handleFileUpload(e.target.files[0]);
        }}
        className="hidden"
      />

      {fileUrl ? (
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
              PDF
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold text-slate-900 block truncate">
                {fileName || 'Ebook PDF uploaded'}
              </span>
              <span className="text-[11px] text-slate-600">
                {uploadedSize ? `Size: ${uploadedSize} · ` : ''}Protected in private ebook storage
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold rounded-lg border border-slate-200"
            >
              Change PDF
            </button>
            <button
              type="button"
              onClick={handleRemoveFile}
              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg border border-rose-200"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="cursor-pointer border-2 border-dashed border-slate-300 hover:border-slate-500 rounded-2xl p-6 text-center bg-slate-50/60 hover:bg-slate-50 transition-all"
        >
          {isUploading ? (
            <div className="py-2 flex flex-col items-center justify-center">
              <RefreshCw className="w-6 h-6 animate-spin text-slate-900 mb-2" />
              <span className="text-xs font-bold text-slate-800">Uploading PDF Document...</span>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center">
              <div className="w-10 h-10 rounded-xl bg-slate-200/70 text-slate-700 flex items-center justify-center mb-2">
                <FileText className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-900">Upload Ebook File (PDF)</span>
              <span className="text-[11px] text-slate-600 mt-0.5">
                Drag & drop or browse your local file (PDF / EPUB up to 50 MB)
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
