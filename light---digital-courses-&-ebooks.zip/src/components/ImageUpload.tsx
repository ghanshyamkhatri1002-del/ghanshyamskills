import React, { useState, useRef } from 'react';
import { Camera, Trash2, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';

interface ImageUploadProps {
  label: string;
  required?: boolean;
  value: string;
  onChange: (url: string) => void;
  uploadEndpoint: string;
  token?: string | null;
  aspectRatio?: 'video' | 'square' | 'auto';
  shape?: 'circle' | 'square' | 'video' | 'banner';
  helperText?: string;
  maxSizeMB?: number;
  theme?: 'dark' | 'light';
}

export const ImageUpload: React.FC<ImageUploadProps> = ({
  label,
  required = false,
  value,
  onChange,
  uploadEndpoint,
  token,
  aspectRatio = 'video',
  shape,
  helperText,
  maxSizeMB = 10,
  theme = 'dark',
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [uploadedMeta, setUploadedMeta] = useState<{
    filename: string;
    size: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleFile = async (file: File) => {
    setErrorMessage('');

    // Format validation
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type.toLowerCase())) {
      setErrorMessage('Only PNG, JPG, JPEG, or WEBP image formats are supported.');
      return;
    }

    // Size validation
    if (file.size > maxSizeMB * 1024 * 1024) {
      setErrorMessage(`Image exceeds maximum allowed size of ${maxSizeMB} MB.`);
      return;
    }

    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('image', file);

      const headers: HeadersInit = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch(uploadEndpoint, {
        method: 'POST',
        headers,
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to upload image');
      }

      onChange(data.url);
      setUploadedMeta({
        filename: data.filename || file.name,
        size: formatFileSize(data.size || file.size),
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Error uploading image. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  };

  const handleRemove = () => {
    onChange('');
    setUploadedMeta(null);
    setErrorMessage('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const effectiveShape = shape || (aspectRatio === 'square' ? 'square' : 'video');
  const isDark = theme === 'dark';

  return (
    <div className="w-full">
      {/* Field Label */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
        <label className={`block text-xs font-bold tracking-wide ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
        {helperText && (
          <span className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            {helperText}
          </span>
        )}
      </div>

      {errorMessage && (
        <div className="mb-3 p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/png, image/jpeg, image/jpg, image/webp"
        onChange={onFileSelect}
        className="hidden"
      />

      {/* Uploaded State: Preview Card */}
      {value ? (
        <div
          className={`rounded-2xl border p-4 transition-all ${
            isDark
              ? 'border-white/[0.1] bg-white/[0.03] hover:border-white/[0.18]'
              : 'border-slate-200 bg-slate-50 hover:border-slate-300'
          }`}
        >
          <div className="flex flex-col sm:flex-row items-center gap-4">
            {/* Preview Box */}
            <div
              className={`relative overflow-hidden shrink-0 border shadow-md ${
                isDark ? 'bg-slate-900 border-white/[0.12]' : 'bg-slate-100 border-slate-200'
              } ${
                effectiveShape === 'circle'
                  ? 'w-24 h-24 rounded-full ring-2 ring-fuchsia-500/40 p-0.5'
                  : effectiveShape === 'square'
                  ? 'w-24 h-24 rounded-xl'
                  : 'w-36 sm:w-44 aspect-video rounded-xl'
              }`}
            >
              <img
                src={value}
                alt="Current Preview"
                className={`w-full h-full object-cover ${effectiveShape === 'circle' ? 'rounded-full' : 'rounded-lg'}`}
              />
            </div>

            <div className="min-w-0 flex-1 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Image Active & Saved</span>
              </div>

              {uploadedMeta ? (
                <div className="mt-1 text-xs text-slate-300">
                  <span className="font-semibold text-white block truncate max-w-xs sm:max-w-md">
                    {uploadedMeta.filename}
                  </span>
                  <span className="text-[11px] text-slate-400">File size: {uploadedMeta.size}</span>
                </div>
              ) : (
                <span className="mt-1 text-[11px] text-slate-400 block truncate max-w-xs sm:max-w-md font-mono">
                  {value.startsWith('http') ? 'External image loaded' : value}
                </span>
              )}

              <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-xl border shadow-sm transition-all flex items-center gap-1.5 cursor-pointer ${
                    isDark
                      ? 'bg-white/[0.08] hover:bg-white/[0.15] text-white border-white/[0.12]'
                      : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                  }`}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isUploading ? 'animate-spin text-fuchsia-400' : ''}`} />
                  <span>Replace Image</span>
                </button>

                <button
                  type="button"
                  onClick={handleRemove}
                  className="px-3.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 text-xs font-bold rounded-xl border border-rose-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Image</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State: Upload Box */
        <div
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 sm:p-8 text-center transition-all ${
            isDragging
              ? isDark
                ? 'border-fuchsia-500 bg-fuchsia-500/10 scale-[1.01]'
                : 'border-slate-900 bg-slate-100 scale-[1.01]'
              : isDark
              ? 'border-white/[0.12] hover:border-fuchsia-500/60 bg-white/[0.02] hover:bg-white/[0.04]'
              : 'border-slate-300 hover:border-slate-500 bg-slate-50 hover:bg-slate-100'
          }`}
        >
          {isUploading ? (
            <div className="py-4 flex flex-col items-center justify-center">
              <RefreshCw className="w-8 h-8 animate-spin text-fuchsia-500 mb-2" />
              <span className="text-xs font-bold text-white">Uploading Image...</span>
              <span className="text-[11px] text-slate-400 mt-1">
                Optimizing and storing file securely
              </span>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center">
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-md mb-3 transition-transform ${
                  isDark
                    ? 'bg-fuchsia-500/15 text-fuchsia-400 border border-fuchsia-500/30'
                    : 'bg-white text-slate-700 border border-slate-200'
                }`}
              >
                <Camera className="w-6 h-6" />
              </div>

              <span className={`text-sm font-bold flex items-center gap-1.5 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                <span>Upload Image</span>
              </span>

              <p className={`mt-1 text-xs font-medium ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                Drag & Drop image here or <span className="text-fuchsia-400 underline font-semibold">Browse file</span>
              </p>

              <div
                className={`mt-3 inline-flex items-center gap-2 text-[11px] px-3 py-1 rounded-full ${
                  isDark ? 'text-slate-400 bg-white/[0.06]' : 'text-slate-600 bg-slate-200/50'
                }`}
              >
                <span>PNG, JPG, JPEG, WEBP</span>
                <span aria-hidden="true">·</span>
                <span>Max {maxSizeMB} MB</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
