import React from 'react';
import { Product } from '../types.ts';
import { PlayCircle, ShoppingBag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onBuyNow: (product: Product) => void;
  onViewDetails: (slug: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onBuyNow,
  onViewDetails,
}) => {
  // Offer badge is STRICTLY admin controlled.
  // Never automatically generate "SAVE 80%".
  const showOfferBadge = Boolean(product.showBadge && product.badgeText?.trim());
  const badgePosition = product.badgePosition || 'top-right';

  const badgePositionClass =
    badgePosition === 'top-left'
      ? 'top-3 left-24' // offset from COURSE badge
      : 'top-3 right-3';

  // Custom styling for badge if configured by admin
  const badgeCustomStyle: React.CSSProperties = {};
  if (product.badgeBgColor) {
    badgeCustomStyle.backgroundColor = product.badgeBgColor;
  }
  if (product.badgeTextColor) {
    badgeCustomStyle.color = product.badgeTextColor;
  }

  return (
    <div className="group relative bg-[#120F1F]/90 hover:bg-[#18132A] rounded-3xl border border-white/[0.08] hover:border-violet-500/50 shadow-2xl shadow-black/50 hover:shadow-violet-950/40 transition-all duration-300 overflow-hidden flex flex-col">
      {/* Subtle ambient hover glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-violet-600/[0.06] via-transparent to-fuchsia-600/[0.06] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

      {/* Course Thumbnail */}
      <div
        onClick={() => onViewDetails(product.slug)}
        className="relative aspect-video w-full bg-slate-950 overflow-hidden cursor-pointer"
      >
        <img
          src={product.thumbnailUrl}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
        />

        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#120F1F] via-transparent to-black/30" />

        {/* COURSE Badge (always present on course cards) */}
        <div className="absolute top-3 left-3 bg-[#0d091a]/90 backdrop-blur-md px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider text-fuchsia-300 shadow-lg flex items-center gap-1.5 border border-fuchsia-500/30">
          <PlayCircle className="w-3.5 h-3.5 text-fuchsia-400" />
          <span>COURSE</span>
        </div>

        {/* Offer Badge: ONLY when enabled by admin with admin text */}
        {showOfferBadge && (
          <div
            style={badgeCustomStyle}
            className={`absolute ${badgePositionClass} bg-gradient-to-r from-pink-500 to-rose-500 text-white font-black text-xs px-2.5 py-1 rounded-xl shadow-lg shadow-pink-500/30 tracking-wider uppercase`}
          >
            {product.badgeText}
          </div>
        )}
      </div>

      {/* Course Information */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between relative z-10">
        <div>
          {/* Title */}
          <h3
            onClick={() => onViewDetails(product.slug)}
            className="font-extrabold text-white text-base sm:text-lg leading-snug cursor-pointer group-hover:text-fuchsia-300 transition-colors line-clamp-2 tracking-tight"
          >
            {product.title}
          </h3>

          {/* Short Description */}
          <p className="mt-2 text-slate-300 text-xs sm:text-sm line-clamp-2 leading-relaxed">
            {product.shortDescription}
          </p>
        </div>

        {/* Pricing & CTA Buttons */}
        <div className="mt-6 pt-4 border-t border-white/[0.08]">
          <div className="flex items-baseline gap-2.5 mb-4">
            <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              ₹{product.price}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs sm:text-sm text-slate-400 line-through">
                ₹{product.originalPrice}
              </span>
            )}
          </div>

          {/* Action Buttons: [ View Course ] [ Buy Now ] */}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => onViewDetails(product.slug)}
              className="w-full py-2.5 px-3 rounded-2xl bg-white/[0.06] hover:bg-white/[0.12] text-slate-200 hover:text-white font-extrabold text-xs transition-all border border-white/[0.1] text-center cursor-pointer"
            >
              View Course
            </button>

            <button
              onClick={() => onBuyNow(product)}
              className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-500 hover:from-violet-500 hover:via-fuchsia-500 hover:to-pink-400 active:scale-95 text-white font-black text-xs shadow-lg shadow-violet-600/30 hover:shadow-fuchsia-500/40 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Buy Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
