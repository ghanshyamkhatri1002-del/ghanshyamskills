import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  LayoutDashboard,
  GraduationCap,
  ShoppingBag,
  Settings,
  LogOut,
  ExternalLink,
  ShieldCheck,
  MessageCircle,
  Menu,
  X,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  navigate: (path: string) => void;
  whatsappNumber?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, navigate, whatsappNumber = '+91 7976028995' }) => {
  const { admin, logout } = useAuth();
  const isAdminRoute = currentPath.startsWith('/admin');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cleanWaNumber = whatsappNumber.replace(/\D/g, '') || '917976028995';
  const whatsappUrl = `https://wa.me/${cleanWaNumber}?text=Hi%20Ghanshyam,%20I%20want%20to%20know%20more%20about%20your%20courses!`;

  if (isAdminRoute && admin) {
    const navItems = [
      { name: 'Dashboard', path: '/admin', icon: LayoutDashboard },
      { name: 'Courses', path: '/admin/products', icon: GraduationCap },
      { name: 'Orders', path: '/admin/orders', icon: ShoppingBag },
      { name: 'Settings', path: '/admin/settings', icon: Settings },
    ];

    return (
      <header className="sticky top-0 z-40 bg-[#0B0A14]/90 backdrop-blur-xl border-b border-white/[0.08] text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button
              onClick={() => navigate('/admin')}
              className="flex items-center gap-2.5 group text-left cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-500 text-white flex items-center justify-center font-black text-sm tracking-wider shadow-lg shadow-violet-500/20 group-hover:scale-105 transition-transform">
                GS
              </div>
              <div>
                <span className="font-extrabold text-white text-sm sm:text-base tracking-tight block">
                  GHANSHYAM SKILLS
                </span>
                <span className="text-[10px] uppercase font-bold text-fuchsia-400 tracking-wider">
                  Admin Panel
                </span>
              </div>
            </button>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1.5 ml-4">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive =
                  item.path === '/admin'
                    ? currentPath === '/admin'
                    : currentPath.startsWith(item.path);
                return (
                  <button
                    key={item.name}
                    onClick={() => navigate(item.path)}
                    className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-md shadow-violet-500/20'
                        : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white px-3.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.1] transition-all cursor-pointer"
              title="View Public Store"
            >
              <span>View Store</span>
              <ExternalLink className="w-3.5 h-3.5 text-fuchsia-400" />
            </button>

            <button
              onClick={async () => {
                await logout();
                navigate('/admin/login');
              }}
              className="flex items-center gap-1.5 text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 px-3 py-1.5 rounded-xl transition-all cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex border-t border-white/[0.06] px-2 py-2 justify-around bg-[#08060f]/90 backdrop-blur-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.path === '/admin'
                ? currentPath === '/admin'
                : currentPath.startsWith(item.path);
            return (
              <button
                key={item.name}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold transition-all ${
                  isActive
                    ? 'text-fuchsia-400 bg-white/[0.08]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.name}</span>
              </button>
            );
          })}
        </div>
      </header>
    );
  }

  // Public Storefront Navigation: Home | Courses | Support | Chat on WhatsApp
  const handleScrollToCourses = () => {
    if (currentPath !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById('courses-section');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    } else {
      const el = document.getElementById('courses-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const handleGoHome = () => {
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const handleScrollToSupport = () => {
    if (currentPath !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById('support-section');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    } else {
      const el = document.getElementById('support-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const directWaUrl = 'https://wa.me/917976028995';

  return (
    <header className="sticky top-0 z-40 bg-[#07050E]/85 backdrop-blur-xl border-b border-white/[0.08] text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <button
          onClick={handleGoHome}
          className="flex items-center gap-2.5 group text-left cursor-pointer"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-500 text-white flex items-center justify-center font-black text-xs shadow-md shadow-violet-500/20 group-hover:scale-105 transition-transform">
            GS
          </div>
          <span className="font-black tracking-tight text-base sm:text-lg bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent group-hover:from-fuchsia-300 group-hover:to-pink-300 transition-all">
            GHANSHYAM SKILLS
          </span>
        </button>

        {/* Desktop Navigation Links: Home | Courses | Support | Chat on WhatsApp */}
        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={handleGoHome}
            className={`text-xs font-bold transition-colors cursor-pointer ${
              currentPath === '/' ? 'text-white' : 'text-slate-300 hover:text-white'
            }`}
          >
            Home
          </button>

          <button
            onClick={handleScrollToCourses}
            className="text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            Courses
          </button>

          <button
            onClick={handleScrollToSupport}
            className="text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            Support
          </button>

          <a
            href={directWaUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-emerald-300 hover:text-emerald-200 text-xs font-bold shadow-sm transition-all"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Chat on WhatsApp</span>
          </a>
        </nav>

        {/* Right side: Admin + Mobile hamburger */}
        <div className="flex items-center gap-2">
          {admin ? (
            <button
              onClick={() => navigate('/admin')}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white px-3.5 py-1.5 rounded-full hover:shadow-lg hover:shadow-violet-500/25 transition-all shadow-sm cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          ) : (
            <button
              onClick={() => navigate('/admin/login')}
              className="hidden sm:inline-flex text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-full hover:bg-white/[0.06] border border-white/[0.08] transition-all cursor-pointer"
            >
              Admin Login
            </button>
          )}

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/[0.08] transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/[0.08] bg-[#0c0919] px-4 py-4 space-y-3 animate-in fade-in">
          <button
            onClick={handleGoHome}
            className="w-full text-left py-2 text-sm font-bold text-white block"
          >
            Home
          </button>
          <button
            onClick={handleScrollToCourses}
            className="w-full text-left py-2 text-sm font-bold text-slate-300 hover:text-white block"
          >
            Courses
          </button>
          <button
            onClick={handleScrollToSupport}
            className="w-full text-left py-2 text-sm font-bold text-slate-300 hover:text-white block cursor-pointer"
          >
            Support
          </button>
          <a
            href={directWaUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-extrabold"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>Chat on WhatsApp</span>
          </a>
          <div className="pt-2 border-t border-white/[0.08]">
            {admin ? (
              <button
                onClick={() => {
                  navigate('/admin');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2 text-xs font-bold text-fuchsia-400 text-left"
              >
                Go to Admin Dashboard
              </button>
            ) : (
              <button
                onClick={() => {
                  navigate('/admin/login');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2 text-xs font-semibold text-slate-400 text-left"
              >
                Admin Login
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
