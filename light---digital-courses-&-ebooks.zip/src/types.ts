export type ProductType = 'course';

export type OrderStatus =
  | 'PENDING'
  | 'PENDING_PAYMENT'
  | 'PAID'
  | 'REJECTED'
  | 'PAYMENT_SUBMITTED'
  | 'APPROVED';

export type AccessStatus = 'ACTIVE' | 'REVOKED';

export interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  description: string;
  supportingFileUrl?: string;
  duration?: string;
}

export interface Product {
  id: string;
  type: ProductType;
  title: string;
  slug: string;
  thumbnailUrl: string;
  shortDescription: string;
  description: string;
  instructor?: string;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  badgeText?: string;
  showBadge?: boolean;
  badgeBgColor?: string;
  badgeTextColor?: string;
  badgePosition?: 'top-right' | 'top-left';
  duration?: string;
  lessonCount?: string;
  contentUrl?: string; // Course URL or Hosted link
  fileUrl?: string; // Private uploaded file path for Course videos/resources
  fileName?: string;
  status: 'active' | 'draft' | 'archived';
  lessons?: Lesson[];
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  whatsappNumber: string;
  createdAt: string;
}

export interface PaymentSubmission {
  id: string;
  orderId: string;
  screenshotUrl: string;
  submittedAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
}

export interface Order {
  id: string;
  customerId: string;
  customer: Customer;
  productId: string;
  product: Product;
  amount: number;
  status: OrderStatus;
  paymentSubmission?: PaymentSubmission;
  productAccess?: ProductAccess;
  createdAt: string;
  updatedAt: string;
}

export interface ProductAccess {
  id: string;
  customerId: string;
  productId: string;
  orderId: string;
  accessToken: string;
  status: AccessStatus;
  createdAt: string;
}

export interface SiteSettings {
  creatorName: string;
  subtitle: string;
  creatorBio: string;
  profileImage: string;
  heroBackgroundImage?: string;
  heroHeading?: string;
  heroSubtitle?: string;
  heroDescription?: string;
  heroCtaText?: string;
  whatsappNumber: string;
  whatsappButtonText: string;
  whatsappButtonIcon?: string;
  whatsappButtonVisible: boolean;
  supportWhatsappNumber: string;
  upiId: string;
  paymentInstructions?: string;
  paymentQrCode: string;
  bgTheme?: string;
  accentColor?: string;
  primaryColor?: string;
  secondaryColor?: string;
  buttonColor?: string;
  footerText?: string;
  socialLinks?: {
    youtube?: string;
    instagram?: string;
    telegram?: string;
    twitter?: string;
  };
  whatsappEnabled: boolean;
  whatsappApiUrl?: string;
  whatsappTokenConfigured?: boolean;
  emailEnabled: boolean;
  smtpConfigured?: boolean;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
}

export interface WhatsAppLog {
  id: string;
  orderId: string;
  recipient: string;
  message: string;
  status: 'SENT' | 'FAILED' | 'MOCK_SENT';
  sentAt: string;
  whatsappWebUrl: string;
}

export interface EmailLog {
  id: string;
  orderId: string;
  recipient: string;
  subject: string;
  body: string;
  status: 'SENT' | 'FAILED' | 'MOCK_SENT';
  sentAt: string;
}
